package com.alidinler.carsi

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.text.InputType
import android.text.TextUtils
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.view.animation.DecelerateInterpolator
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.RenderProcessGoneDetail
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.concurrent.Executors

data class Shop(val id: String, val name: String, val url: String)

data class Palette(
    val key: String,
    val label: String,
    val bg: Int,
    val surface: Int,
    val surface2: Int,
    val text: Int,
    val sub: Int,
    val accent: Int,
    val divider: Int,
    val light: Boolean
)

class MainActivity : Activity() {

    companion object {
        private const val REQ_FILE = 4711
        private const val MAX_LIVE_SHOPS = 4
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

        private fun c(hex: Long): Int = hex.toInt()

        val PALETTES = listOf(
            Palette("black", "Siyah", c(0xFF000000), c(0xFF17171A), c(0xFF232328), Color.WHITE, c(0xFF9C9CA6), c(0xFFF2B33D), c(0xFF2A2A30), false),
            Palette("white", "Beyaz", c(0xFFFFFFFF), c(0xFFF1F2F5), c(0xFFE4E6EB), c(0xFF14161B), c(0xFF6A7079), c(0xFFC9771A), c(0xFFE2E4E9), true),
            Palette("navy", "Koyu mavi", c(0xFF0A1A36), c(0xFF13284D), c(0xFF1B3561), Color.WHITE, c(0xFFA3B5D4), c(0xFF5EE6D8), c(0xFF213C6B), false),
            Palette("maroon", "Koyu kırmızı", c(0xFF3D0A12), c(0xFF55121C), c(0xFF681A26), Color.WHITE, c(0xFFDDAAB1), c(0xFFF2B33D), c(0xFF6E1F2B), false)
        )

        val LETTER_COLORS = intArrayOf(
            c(0xFFE8590C), c(0xFF1C7ED6), c(0xFF2F9E44), c(0xFFC2255C),
            c(0xFF7048E8), c(0xFF0C8599), c(0xFFE67700), c(0xFFD6336C)
        )
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var palette: Palette
    private var shops = mutableListOf<Shop>()

    private lateinit var root: FrameLayout
    private lateinit var homeLayer: FrameLayout
    private lateinit var gridBox: LinearLayout
    private lateinit var shopLayer: LinearLayout
    private lateinit var shopTitle: TextView
    private lateinit var shopIcon: ImageView
    private lateinit var progress: ProgressBar
    private lateinit var webHolder: FrameLayout

    private var settingsLayer: View? = null
    private var settingsScroll: ScrollView? = null

    private val webViews = LinkedHashMap<String, WebView>(8, 0.75f, true)
    private var activeWeb: WebView? = null
    private var spare: WebView? = null
    private var currentShop: Shop? = null

    private var popupWeb: WebView? = null
    private var popupBox: View? = null
    private var popupTitle: TextView? = null

    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val main = Handler(Looper.getMainLooper())
    private val ioPool = Executors.newFixedThreadPool(4)
    private val iconCache = LruCache<String, Bitmap>(80)

    private val Int.dp: Int get() = (this * resources.displayMetrics.density + 0.5f).toInt()

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("carsi", MODE_PRIVATE)
        palette = PALETTES.firstOrNull { it.key == prefs.getString("bg", "black") } ?: PALETTES[0]
        loadShops()
        CookieManager.getInstance().setAcceptCookie(true)

        root = FrameLayout(this)
        setContentView(root)
        buildUi()

        // Prepare the web engine in the background so the first shop opens instantly.
        main.postDelayed({ prewarm() }, 300)
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
        activeWeb?.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::shopLayer.isInitialized && shopLayer.visibility == View.VISIBLE) activeWeb?.onResume()
    }

    override fun onDestroy() {
        closePopup(null)
        for (w in webViews.values) {
            try { w.destroy() } catch (e: Exception) { }
        }
        webViews.clear()
        spare?.destroy()
        spare = null
        ioPool.shutdownNow()
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::gridBox.isInitialized) fillGrid()
        if (settingsLayer != null) openSettings(animate = false, keepScroll = true)
    }

    @Deprecated("Uses the classic back handling on purpose")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val pw = popupWeb
        when {
            settingsLayer != null -> closeSettings()
            pw != null -> if (pw.canGoBack()) pw.goBack() else closePopup(null)
            shopLayer.visibility == View.VISIBLE -> {
                val w = activeWeb
                if (w != null && w.canGoBack()) w.goBack() else goHome()
            }
            else -> super.onBackPressed()
        }
    }

    @Deprecated("Needed for the web page file picker")
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_FILE) {
            fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCallback = null
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    // ------------------------------------------------------------------ data

    private fun defaultShops(): List<Shop> = listOf(
        Shop("trendyol", "Trendyol", "https://www.trendyol.com"),
        Shop("hepsiburada", "Hepsiburada", "https://www.hepsiburada.com"),
        Shop("amazon", "Amazon", "https://www.amazon.com.tr"),
        Shop("n11", "n11", "https://www.n11.com"),
        Shop("ciceksepeti", "Çiçeksepeti", "https://www.ciceksepeti.com"),
        Shop("pazarama", "Pazarama", "https://www.pazarama.com"),
        Shop("temu", "Temu", "https://www.temu.com"),
        Shop("aliexpress", "AliExpress", "https://www.aliexpress.com"),
        Shop("migros", "Migros", "https://www.migros.com.tr"),
        Shop("a101", "A101", "https://www.a101.com.tr"),
        Shop("yemeksepeti", "Yemeksepeti", "https://www.yemeksepeti.com"),
        Shop("lcw", "LC Waikiki", "https://www.lcw.com"),
        Shop("defacto", "DeFacto", "https://www.defacto.com.tr"),
        Shop("boyner", "Boyner", "https://www.boyner.com.tr"),
        Shop("teknosa", "Teknosa", "https://www.teknosa.com"),
        Shop("mediamarkt", "MediaMarkt", "https://www.mediamarkt.com.tr"),
        Shop("vatan", "Vatan Bilgisayar", "https://www.vatanbilgisayar.com"),
        Shop("decathlon", "Decathlon", "https://www.decathlon.com.tr"),
        Shop("ikea", "IKEA", "https://www.ikea.com.tr"),
        Shop("koctas", "Koçtaş", "https://www.koctas.com.tr"),
        Shop("gratis", "Gratis", "https://www.gratis.com"),
        Shop("watsons", "Watsons", "https://www.watsons.com.tr"),
        Shop("sahibinden", "Sahibinden", "https://www.sahibinden.com"),
        Shop("dolap", "Dolap", "https://dolap.com")
    )

    private fun loadShops() {
        val raw = prefs.getString("shops", null)
        if (raw == null) {
            shops = defaultShops().toMutableList()
            return
        }
        val list = mutableListOf<Shop>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(Shop(o.getString("id"), o.getString("name"), o.getString("url")))
            }
        } catch (e: Exception) {
            list.clear()
            list.addAll(defaultShops())
        }
        shops = list
    }

    private fun saveShops() {
        val arr = JSONArray()
        for (s in shops) {
            arr.put(JSONObject().put("id", s.id).put("name", s.name).put("url", s.url))
        }
        prefs.edit().putString("shops", arr.toString()).apply()
    }

    // ------------------------------------------------------------------ small helpers

    private fun isTablet(): Boolean = resources.configuration.smallestScreenWidthDp >= 600

    private fun withAlpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha shl 24)

    private fun rounded(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun csl(color: Int): ColorStateList = ColorStateList.valueOf(color)

    private fun match(): FrameLayout.LayoutParams = FrameLayout.LayoutParams(MATCH, MATCH)

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun label(s: String, size: Float, color: Int, family: String = "sans-serif", style: Int = Typeface.NORMAL): TextView =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            typeface = Typeface.create(family, style)
            includeFontPadding = true
        }

    private fun iconButton(res: Int, desc: String, tint: Int = palette.text, onClick: () -> Unit): ImageView =
        ImageView(this).apply {
            setImageResource(res)
            imageTintList = csl(tint)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(12.dp, 12.dp, 12.dp, 12.dp)
            background = RippleDrawable(csl(withAlpha(palette.text, 0x33)), null, null)
            contentDescription = desc
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }

    private fun hostOf(url: String): String = Uri.parse(url).host ?: url

    private fun letterColor(name: String): Int = LETTER_COLORS[(name.hashCode() and 0x7FFFFFFF) % LETTER_COLORS.size]

    private fun dialogBuilder(): AlertDialog.Builder =
        AlertDialog.Builder(
            this,
            if (palette.light) android.R.style.Theme_DeviceDefault_Light_Dialog_Alert
            else android.R.style.Theme_DeviceDefault_Dialog_Alert
        )

    private fun greeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (h) {
            in 5..11 -> "Günaydın"
            in 12..17 -> "İyi günler"
            in 18..22 -> "İyi akşamlar"
            else -> "İyi geceler"
        }
    }

    @Suppress("DEPRECATION")
    private fun applySystemBars() {
        window.statusBarColor = palette.bg
        window.navigationBarColor = palette.bg
        if (Build.VERSION.SDK_INT >= 30) {
            val flags = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            window.insetsController?.setSystemBarsAppearance(if (palette.light) flags else 0, flags)
        } else {
            val lightFlags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            var f = window.decorView.systemUiVisibility
            f = if (palette.light) f or lightFlags else f and lightFlags.inv()
            window.decorView.systemUiVisibility = f
        }
    }

    // ------------------------------------------------------------------ icons (each shop's own site icon)

    private fun loadIcon(url: String, onReady: (Bitmap) -> Unit) {
        val host = hostOf(url)
        val cached = iconCache.get(host)
        if (cached != null) {
            onReady(cached)
            return
        }
        ioPool.execute {
            var bmp: Bitmap? = null
            val file = File(cacheDir, "icons/$host.png")
            if (file.exists()) bmp = BitmapFactory.decodeFile(file.path)
            if (bmp == null) {
                try {
                    val conn = URL("https://www.google.com/s2/favicons?domain=$host&sz=128").openConnection() as HttpURLConnection
                    conn.connectTimeout = 7000
                    conn.readTimeout = 7000
                    val bytes = conn.inputStream.use { it.readBytes() }
                    conn.disconnect()
                    val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (decoded != null && decoded.width >= 32) {
                        bmp = decoded
                        file.parentFile?.mkdirs()
                        file.writeBytes(bytes)
                    }
                } catch (e: Exception) {
                }
            }
            val result = bmp
            if (result != null) {
                iconCache.put(host, result)
                main.post { onReady(result) }
            }
        }
    }

    // ------------------------------------------------------------------ UI building

    private fun buildUi() {
        root.removeAllViews()
        settingsLayer = null
        settingsScroll = null
        root.setBackgroundColor(palette.bg)
        window.decorView.setBackgroundColor(palette.bg)

        homeLayer = buildHome()
        root.addView(homeLayer, match())

        shopLayer = buildShopLayer()
        shopLayer.visibility = View.GONE
        root.addView(shopLayer, match())

        applySystemBars()
    }

    private fun buildHome(): FrameLayout {
        val layer = FrameLayout(this)
        layer.setBackgroundColor(palette.bg)

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.isVerticalScrollBarEnabled = false

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val side = if (isTablet()) 34.dp else 14.dp
        col.setPadding(side, if (isTablet()) 30.dp else 18.dp, side, 32.dp)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(6.dp, 0, 0, 0)

        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.addView(label(greeting(), if (isTablet()) 17f else 15f, palette.sub))
        val title = label("Online AVM", if (isTablet()) 46f else 38f, palette.text, "sans-serif-black")
        title.letterSpacing = -0.02f
        titles.addView(title)
        titles.addView(label("Bugün hangi mağazaya giriyoruz?", if (isTablet()) 17f else 15f, palette.sub))
        header.addView(titles, LinearLayout.LayoutParams(0, WRAP, 1f))

        header.addView(iconButton(R.drawable.ic_settings, "Ayarlar") { openSettings(animate = true) },
            LinearLayout.LayoutParams(52.dp, 52.dp))
        col.addView(header)

        // Thin gold rule under the title: the one decorative touch on the home screen.
        val rule = View(this)
        rule.background = rounded(palette.accent, 2.dp.toFloat())
        col.addView(rule, LinearLayout.LayoutParams(44.dp, 4.dp).apply {
            topMargin = 14.dp; bottomMargin = 18.dp; leftMargin = 6.dp
        })

        gridBox = LinearLayout(this)
        gridBox.orientation = LinearLayout.VERTICAL
        col.addView(gridBox, LinearLayout.LayoutParams(MATCH, WRAP))
        fillGrid()

        scroll.addView(col)
        layer.addView(scroll, match())
        return layer
    }

    private fun fillGrid() {
        gridBox.removeAllViews()
        val w = resources.configuration.screenWidthDp
        val cols = when {
            w >= 1100 -> 6
            w >= 840 -> 5
            w >= 600 -> 4
            else -> 3
        }
        val tileH = if (isTablet()) 156.dp else 122.dp
        val total = shops.size + 1
        var row: LinearLayout? = null
        for (i in 0 until total) {
            if (i % cols == 0) {
                val r = LinearLayout(this)
                r.orientation = LinearLayout.HORIZONTAL
                gridBox.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
                row = r
            }
            val tile = if (i < shops.size) shopTile(shops[i]) else addTile()
            row?.addView(tile, tileParams(tileH))
        }
        val rem = total % cols
        if (rem != 0) {
            for (k in 0 until cols - rem) row?.addView(View(this), tileParams(tileH))
        }
    }

    private fun tileParams(h: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, h, 1f).apply { setMargins(6.dp, 6.dp, 6.dp, 6.dp) }

    private fun tileBackground(): RippleDrawable =
        RippleDrawable(
            csl(withAlpha(palette.accent, 0x55)),
            rounded(palette.surface, 22.dp.toFloat()),
            rounded(Color.WHITE, 22.dp.toFloat())
        )

    private fun pressAnim(v: View) {
        v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(70).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()
    }

    private fun shopTile(shop: Shop): View {
        val tile = LinearLayout(this)
        tile.orientation = LinearLayout.VERTICAL
        tile.gravity = Gravity.CENTER
        tile.background = tileBackground()
        tile.isClickable = true
        tile.isFocusable = true
        if (palette.light) tile.elevation = 1.5f * resources.displayMetrics.density

        val box = FrameLayout(this)
        box.background = rounded(Color.WHITE, 16.dp.toFloat())
        val letter = label(shop.name.take(1).uppercase(), if (isTablet()) 28f else 24f, letterColor(shop.name), "sans-serif-black")
        letter.gravity = Gravity.CENTER
        box.addView(letter, FrameLayout.LayoutParams(MATCH, MATCH))
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        img.visibility = View.GONE
        val pad = if (isTablet()) 12.dp else 10.dp
        box.addView(img, FrameLayout.LayoutParams(MATCH, MATCH).apply { setMargins(pad, pad, pad, pad) })
        val boxSize = if (isTablet()) 68.dp else 54.dp
        tile.addView(box, LinearLayout.LayoutParams(boxSize, boxSize))

        val name = label(shop.name, if (isTablet()) 16f else 13f, palette.text, "sans-serif-medium")
        name.gravity = Gravity.CENTER
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        tile.addView(name, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            topMargin = if (isTablet()) 14.dp else 10.dp; leftMargin = 6.dp; rightMargin = 6.dp
        })

        loadIcon(shop.url) { bmp ->
            img.setImageBitmap(bmp)
            img.visibility = View.VISIBLE
            letter.visibility = View.GONE
        }

        tile.setOnClickListener {
            pressAnim(it)
            openShop(shop, animate = true)
        }
        tile.setOnLongClickListener {
            tileMenu(shop)
            true
        }
        return tile
    }

    private fun addTile(): View {
        val tile = LinearLayout(this)
        tile.orientation = LinearLayout.VERTICAL
        tile.gravity = Gravity.CENTER
        val bg = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            cornerRadius = 22.dp.toFloat()
            setStroke(2.dp, palette.divider, 10.dp.toFloat(), 6.dp.toFloat())
        }
        tile.background = RippleDrawable(csl(withAlpha(palette.accent, 0x55)), bg, rounded(Color.WHITE, 22.dp.toFloat()))
        tile.isClickable = true
        val plus = ImageView(this)
        plus.setImageResource(R.drawable.ic_add)
        plus.imageTintList = csl(palette.sub)
        tile.addView(plus, LinearLayout.LayoutParams(34.dp, 34.dp))
        tile.addView(label("Mağaza ekle", if (isTablet()) 15f else 13f, palette.sub, "sans-serif-medium").apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = 8.dp })
        tile.setOnClickListener {
            pressAnim(it)
            showAddShopDialog()
        }
        return tile
    }

    private fun buildShopLayer(): LinearLayout {
        val layer = LinearLayout(this)
        layer.orientation = LinearLayout.VERTICAL
        layer.setBackgroundColor(palette.bg)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(4.dp, 0, 4.dp, 0)
        bar.setBackgroundColor(palette.bg)

        bar.addView(iconButton(R.drawable.ic_back, "Geri") { pageBack() }, LinearLayout.LayoutParams(50.dp, 50.dp))

        shopIcon = ImageView(this)
        shopIcon.background = rounded(Color.WHITE, 8.dp.toFloat())
        shopIcon.setPadding(3.dp, 3.dp, 3.dp, 3.dp)
        shopIcon.scaleType = ImageView.ScaleType.FIT_CENTER
        bar.addView(shopIcon, LinearLayout.LayoutParams(30.dp, 30.dp).apply { leftMargin = 4.dp; rightMargin = 12.dp })

        shopTitle = label("", 18f, palette.text, "sans-serif-medium")
        shopTitle.maxLines = 1
        shopTitle.ellipsize = TextUtils.TruncateAt.END
        bar.addView(shopTitle, LinearLayout.LayoutParams(0, WRAP, 1f))

        bar.addView(iconButton(R.drawable.ic_refresh, "Yenile") { activeWeb?.reload() }, LinearLayout.LayoutParams(50.dp, 50.dp))
        bar.addView(iconButton(R.drawable.ic_home, "Ana sayfa") { goHome() }, LinearLayout.LayoutParams(50.dp, 50.dp))
        layer.addView(bar, LinearLayout.LayoutParams(MATCH, 56.dp))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 100
        progress.isIndeterminate = false
        progress.progressTintList = csl(palette.accent)
        progress.progressBackgroundTintList = csl(palette.divider)
        layer.addView(progress, LinearLayout.LayoutParams(MATCH, 3.dp))

        webHolder = FrameLayout(this)
        webHolder.setBackgroundColor(Color.WHITE)
        layer.addView(webHolder, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return layer
    }

    // ------------------------------------------------------------------ web engine

    private fun buildUserAgent(): String {
        var ua = try { WebSettings.getDefaultUserAgent(this) } catch (e: Exception) { "" }
        if (ua.isEmpty()) {
            ua = "Mozilla/5.0 (Linux; Android ${Build.VERSION.RELEASE}; ${Build.MODEL}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        }
        // Look like the normal Chrome app (not an embedded view) so account sign-in pages, including Google's, open.
        ua = ua.replace("; wv)", ")").replace(Regex("Version/\\d+(\\.\\d+)* "), "")
        val chrome = Regex("Chrome/([\\d.]+)").find(ua)?.groupValues?.get(1) ?: "124.0.0.0"
        return when (prefs.getString("viewMode", "auto")) {
            "desktop" -> "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$chrome Safari/537.36"
            "phone" -> if (ua.contains("Mobile Safari")) ua else ua.replace(" Safari/", " Mobile Safari/")
            else -> if (isTablet()) ua.replace(" Mobile Safari/", " Safari/") else ua
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(wv: WebView) {
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportMultipleWindows(true)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.loadsImagesAutomatically = true
        s.mediaPlaybackRequiresUserGesture = true
        s.offscreenPreRaster = true
        s.textZoom = 100
        s.userAgentString = buildUserAgent()
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        hideRequestedWithHeader(s)
        wv.setBackgroundColor(Color.WHITE)
        wv.isVerticalScrollBarEnabled = false
        wv.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true)
        wv.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            startDownload(url, userAgent, contentDisposition, mimetype)
        }
    }

    // Stops the page from being told it runs inside an app (helps Google sign-in). Silently skipped on old engines.
    private fun hideRequestedWithHeader(s: WebSettings) {
        try {
            val cls = Class.forName("androidx.webkit.WebSettingsCompat")
            val m = cls.getMethod("setRequestedWithHeaderOriginAllowList", WebSettings::class.java, Set::class.java)
            m.invoke(null, s, emptySet<String>())
        } catch (e: Throwable) {
        }
    }

    private fun createWebView(): WebView {
        val wv = WebView(this)
        configureWebView(wv)
        wv.webViewClient = ShopClient()
        wv.webChromeClient = ShopChrome()
        return wv
    }

    private fun prewarm() {
        if (spare == null && !isFinishing && !isDestroyed) {
            try { spare = createWebView() } catch (e: Exception) { }
        }
    }

    private fun applyUserAgentToAll() {
        val ua = buildUserAgent()
        for (w in webViews.values) w.settings.userAgentString = ua
        spare?.settings?.userAgentString = ua
        for (w in webViews.values) w.reload()
    }

    private fun startDownload(url: String, userAgent: String?, contentDisposition: String?, mimetype: String?) {
        if (!url.startsWith("http")) {
            toast("Bu dosya bu şekilde indirilemiyor")
            return
        }
        try {
            val name = URLUtil.guessFileName(url, contentDisposition, mimetype)
            val req = DownloadManager.Request(Uri.parse(url))
            if (mimetype != null) req.setMimeType(mimetype)
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            if (userAgent != null) req.addRequestHeader("User-Agent", userAgent)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("İndiriliyor: $name")
        } catch (e: Exception) {
            toast("Dosya indirilemedi")
        }
    }

    /** Returns true when the link must NOT be loaded inside the page. Keeps shopping inside the app. */
    private fun handleScheme(view: WebView, uri: Uri): Boolean {
        val scheme = (uri.scheme ?: "").lowercase()
        return when (scheme) {
            "http", "https", "about", "data", "blob", "javascript" -> false
            "intent" -> {
                // Sites try to throw you into their own app; load their web fallback instead and stay here.
                try {
                    val intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                    val fb = intent.getStringExtra("browser_fallback_url")
                    if (fb != null && fb.startsWith("http") && fb != view.url) view.loadUrl(fb)
                } catch (e: Exception) {
                }
                true
            }
            "tel", "mailto", "sms", "smsto", "geo", "whatsapp" -> {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (e: Exception) {
                    toast("Bu bağlantı açılamadı")
                }
                true
            }
            else -> true
        }
    }

    private fun handleRenderGone(view: WebView) {
        if (view === popupWeb) {
            closePopup(null)
            return
        }
        if (view === spare) {
            spare = null
            try { view.destroy() } catch (e: Exception) { }
            return
        }
        var key: String? = null
        for ((k, v) in webViews) if (v === view) key = k
        (view.parent as? ViewGroup)?.removeView(view)
        try { view.destroy() } catch (e: Exception) { }
        if (key != null) {
            webViews.remove(key)
            val cur = currentShop
            if (cur != null && cur.id == key && shopLayer.visibility == View.VISIBLE) openShop(cur, animate = false)
        }
    }

    inner class ShopClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val v = view ?: return false
            val u = request?.url ?: return false
            return handleScheme(v, u)
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            CookieManager.getInstance().flush()
        }

        override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
            if (view != null) main.post { handleRenderGone(view) }
            return true
        }
    }

    inner class PopupClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val v = view ?: return false
            val u = request?.url ?: return false
            return handleScheme(v, u)
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            if (url != null && url.startsWith("http")) popupTitle?.text = hostOf(url).removePrefix("www.")
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            CookieManager.getInstance().flush()
        }

        override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
            main.post { closePopup(null) }
            return true
        }
    }

    inner class ShopChrome : WebChromeClient() {
        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            if (view != null && view === activeWeb) updateProgress(newProgress)
        }

        // "Google ile giriş" and similar buttons open a small window: show it as a sheet inside the app.
        override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
            val msg = resultMsg ?: return false
            val popup = createPopup()
            val transport = msg.obj as WebView.WebViewTransport
            transport.webView = popup
            msg.sendToTarget()
            return true
        }

        override fun onCloseWindow(window: WebView?) {
            closePopup(window)
        }

        @Suppress("DEPRECATION")
        override fun onShowFileChooser(
            webView: WebView?,
            filePathCallback: ValueCallback<Array<Uri>>?,
            fileChooserParams: FileChooserParams?
        ): Boolean {
            fileCallback?.onReceiveValue(null)
            fileCallback = filePathCallback
            return try {
                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(intent, REQ_FILE)
                true
            } catch (e: Exception) {
                fileCallback = null
                false
            }
        }

        override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
            callback?.invoke(origin, false, false)
        }
    }

    private fun createPopup(): WebView {
        closePopup(null)
        val wv = WebView(this)
        configureWebView(wv)
        wv.webViewClient = PopupClient()
        wv.webChromeClient = ShopChrome()

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundColor(palette.bg)
        box.isClickable = true
        box.elevation = 10.dp.toFloat()

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(4.dp, 0, 12.dp, 0)
        bar.addView(iconButton(R.drawable.ic_close, "Kapat") { closePopup(null) }, LinearLayout.LayoutParams(50.dp, 50.dp))
        val title = label("Giriş", 16f, palette.sub, "sans-serif-medium")
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        bar.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        box.addView(bar, LinearLayout.LayoutParams(MATCH, 52.dp))
        box.addView(wv, LinearLayout.LayoutParams(MATCH, 0, 1f))

        webHolder.addView(box, match())
        box.alpha = 0f
        box.translationY = 40.dp.toFloat()
        box.animate().alpha(1f).translationY(0f).setDuration(200).setInterpolator(DecelerateInterpolator()).start()

        popupWeb = wv
        popupBox = box
        popupTitle = title
        return wv
    }

    private fun closePopup(target: WebView?) {
        val wv = popupWeb ?: return
        if (target != null && target !== wv) return
        val box = popupBox
        popupWeb = null
        popupBox = null
        popupTitle = null
        if (box != null) (box.parent as? ViewGroup)?.removeView(box)
        main.post {
            try {
                wv.stopLoading()
                wv.destroy()
            } catch (e: Exception) {
            }
        }
    }

    // ------------------------------------------------------------------ navigation

    private fun openShop(shop: Shop, animate: Boolean) {
        if (currentShop?.id != shop.id) closePopup(null)
        currentShop = shop
        shopTitle.text = shop.name
        shopIcon.setImageDrawable(null)
        loadIcon(shop.url) { bmp -> if (currentShop?.id == shop.id) shopIcon.setImageBitmap(bmp) }

        val existing = webViews[shop.id]
        val wv: WebView
        if (existing != null) {
            wv = existing
        } else {
            wv = spare ?: createWebView()
            spare = null
            webViews[shop.id] = wv
            wv.loadUrl(shop.url)
            trimWebViews(shop.id)
        }

        for (other in webViews.values) {
            if (other !== wv && other.parent != null) {
                (other.parent as? ViewGroup)?.removeView(other)
                other.onPause()
            }
        }
        if (wv.parent !== webHolder) {
            (wv.parent as? ViewGroup)?.removeView(wv)
            webHolder.addView(wv, 0, match())
        }
        activeWeb = wv
        wv.onResume()
        updateProgress(wv.progress)
        showShopLayer(animate)

        // Keep a fresh engine ready for the next shop.
        main.postDelayed({ prewarm() }, 900)
    }

    private fun trimWebViews(keep: String) {
        while (webViews.size > MAX_LIVE_SHOPS) {
            val eldest = webViews.keys.firstOrNull { it != keep } ?: break
            val w = webViews.remove(eldest) ?: break
            (w.parent as? ViewGroup)?.removeView(w)
            try { w.destroy() } catch (e: Exception) { }
        }
    }

    private fun showShopLayer(animate: Boolean) {
        shopLayer.animate().cancel()
        shopLayer.visibility = View.VISIBLE
        if (animate) {
            shopLayer.alpha = 0f
            shopLayer.translationY = 20.dp.toFloat()
            shopLayer.animate().alpha(1f).translationY(0f).setDuration(190)
                .setInterpolator(DecelerateInterpolator())
                .withEndAction { if (shopLayer.visibility == View.VISIBLE) homeLayer.visibility = View.INVISIBLE }
                .start()
        } else {
            shopLayer.alpha = 1f
            shopLayer.translationY = 0f
            homeLayer.visibility = View.INVISIBLE
        }
    }

    private fun pageBack() {
        val pw = popupWeb
        if (pw != null) {
            if (pw.canGoBack()) pw.goBack() else closePopup(null)
            return
        }
        val w = activeWeb
        if (w != null && w.canGoBack()) w.goBack() else goHome()
    }

    private fun goHome() {
        closePopup(null)
        homeLayer.visibility = View.VISIBLE
        shopLayer.animate().cancel()
        shopLayer.animate().alpha(0f).translationY(20.dp.toFloat()).setDuration(160)
            .withEndAction {
                shopLayer.visibility = View.GONE
                activeWeb?.onPause()
            }.start()
    }

    private fun updateProgress(p: Int) {
        progress.progress = p
        if (p >= 100) {
            progress.animate().alpha(0f).setDuration(260).start()
        } else {
            progress.animate().cancel()
            progress.alpha = 1f
        }
    }

    // ------------------------------------------------------------------ shop management

    private fun tileMenu(shop: Shop) {
        dialogBuilder()
            .setTitle(shop.name)
            .setItems(arrayOf("En başa taşı", "Ana sayfadan kaldır")) { _, which ->
                when (which) {
                    0 -> {
                        shops.remove(shop)
                        shops.add(0, shop)
                    }
                    1 -> removeShop(shop)
                }
                saveShops()
                fillGrid()
            }
            .show()
    }

    private fun removeShop(shop: Shop) {
        shops.remove(shop)
        webViews.remove(shop.id)?.let { w ->
            (w.parent as? ViewGroup)?.removeView(w)
            try { w.destroy() } catch (e: Exception) { }
        }
        if (currentShop?.id == shop.id) {
            currentShop = null
            activeWeb = null
        }
    }

    private fun showAddShopDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(22.dp, 8.dp, 22.dp, 0)
        val nameEt = EditText(this).apply {
            hint = "Mağaza adı (ör. Koton)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            setSingleLine()
        }
        val urlEt = EditText(this).apply {
            hint = "Adresi (ör. koton.com)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        box.addView(nameEt)
        box.addView(urlEt)
        dialogBuilder()
            .setTitle("Mağaza ekle")
            .setView(box)
            .setPositiveButton("Ekle") { _, _ ->
                val name = nameEt.text.toString().trim()
                var url = urlEt.text.toString().trim().replace(" ", "")
                if (name.isEmpty() || url.isEmpty()) {
                    toast("Mağaza adı ve adresi gerekli")
                    return@setPositiveButton
                }
                if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://$url"
                if (Uri.parse(url).host.isNullOrEmpty()) {
                    toast("Adres geçersiz, ör. koton.com yazın")
                    return@setPositiveButton
                }
                shops.add(Shop("c" + System.currentTimeMillis(), name, url))
                saveShops()
                fillGrid()
                refreshSettingsIfOpen()
                toast("$name eklendi")
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    // ------------------------------------------------------------------ settings

    private fun refreshSettingsIfOpen() {
        if (settingsLayer != null) openSettings(animate = false, keepScroll = true)
    }

    private fun applyPalette(p: Palette) {
        if (p.key == palette.key) return
        palette = p
        prefs.edit().putString("bg", p.key).apply()
        val shopOpen = shopLayer.visibility == View.VISIBLE
        closePopup(null)
        for (w in webViews.values) (w.parent as? ViewGroup)?.removeView(w)
        buildUi()
        val cur = currentShop
        if (shopOpen && cur != null) openShop(cur, animate = false)
        openSettings(animate = false, keepScroll = false)
    }

    private fun sectionTitle(text: String): TextView =
        label(text, 15f, palette.accent, "sans-serif-medium").apply {
            setPadding(6.dp, 26.dp, 0, 10.dp)
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(palette.surface, 20.dp.toFloat())
        setPadding(18.dp, 14.dp, 18.dp, 14.dp)
    }

    private fun actionRow(title: String, sub: String?, color: Int = palette.text, onClick: () -> Unit): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.VERTICAL
        row.setPadding(4.dp, 12.dp, 4.dp, 12.dp)
        row.background = RippleDrawable(csl(withAlpha(palette.text, 0x22)), null, rounded(Color.WHITE, 12.dp.toFloat()))
        row.isClickable = true
        row.addView(label(title, 16f, color, "sans-serif-medium"))
        if (sub != null) row.addView(label(sub, 13f, palette.sub).apply { setPadding(0, 3.dp, 0, 0) })
        row.setOnClickListener { onClick() }
        return row
    }

    private fun openSettings(animate: Boolean, keepScroll: Boolean = false) {
        val oldScroll = if (keepScroll) (settingsScroll?.scrollY ?: 0) else 0
        settingsLayer?.let { root.removeView(it) }

        val layer = LinearLayout(this)
        layer.orientation = LinearLayout.VERTICAL
        layer.setBackgroundColor(palette.bg)
        layer.isClickable = true

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(4.dp, 0, 4.dp, 0)
        bar.addView(iconButton(R.drawable.ic_back, "Geri") { closeSettings() }, LinearLayout.LayoutParams(50.dp, 50.dp))
        bar.addView(label("Ayarlar", 21f, palette.text, "sans-serif-medium").apply { setPadding(8.dp, 0, 0, 0) },
            LinearLayout.LayoutParams(0, WRAP, 1f))
        layer.addView(bar, LinearLayout.LayoutParams(MATCH, 58.dp))

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val screenW = resources.displayMetrics.widthPixels
        val side = Math.max(16.dp, (screenW - 720.dp) / 2)
        col.setPadding(side, 0, side, 40.dp)

        // Background colour
        col.addView(sectionTitle("Arka plan rengi"))
        val colors = card()
        val swatches = LinearLayout(this)
        swatches.orientation = LinearLayout.HORIZONTAL
        for (p in PALETTES) {
            val selected = p.key == palette.key
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER_HORIZONTAL
            item.setPadding(0, 8.dp, 0, 8.dp)
            item.isClickable = true
            item.background = RippleDrawable(csl(withAlpha(palette.text, 0x22)), null, rounded(Color.WHITE, 14.dp.toFloat()))
            val circleBox = FrameLayout(this)
            val circle = View(this)
            circle.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(p.bg)
                if (selected) setStroke(3.dp, palette.accent) else setStroke(1.dp, c(0x66888888))
            }
            circleBox.addView(circle, FrameLayout.LayoutParams(MATCH, MATCH))
            if (selected) {
                val tick = label("✓", 22f, if (p.light) Color.BLACK else Color.WHITE, "sans-serif-medium")
                tick.gravity = Gravity.CENTER
                circleBox.addView(tick, FrameLayout.LayoutParams(MATCH, MATCH))
            }
            item.addView(circleBox, LinearLayout.LayoutParams(52.dp, 52.dp))
            item.addView(label(p.label, 13f, if (selected) palette.text else palette.sub, "sans-serif-medium").apply {
                gravity = Gravity.CENTER
                setPadding(0, 8.dp, 0, 0)
            })
            item.setOnClickListener { applyPalette(p) }
            swatches.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        colors.addView(swatches)
        col.addView(colors)

        // Page layout
        col.addView(sectionTitle("Mağaza sayfalarının görünümü"))
        val modes = card()
        val current = prefs.getString("viewMode", "auto")
        val options = listOf(
            Triple("auto", "Otomatik", "Tablette tam ekran geniş sayfa, telefonda mobil sayfa"),
            Triple("phone", "Telefon görünümü", "Her cihazda mobil sayfa, yine tam ekran"),
            Triple("desktop", "Bilgisayar görünümü", "Sitelerin bilgisayardaki hali")
        )
        for ((key, title, sub) in options) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(4.dp, 12.dp, 4.dp, 12.dp)
            row.isClickable = true
            row.background = RippleDrawable(csl(withAlpha(palette.text, 0x22)), null, rounded(Color.WHITE, 12.dp.toFloat()))
            val texts = LinearLayout(this)
            texts.orientation = LinearLayout.VERTICAL
            texts.addView(label(title, 16f, palette.text, "sans-serif-medium"))
            texts.addView(label(sub, 13f, palette.sub).apply { setPadding(0, 3.dp, 0, 0) })
            row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))
            val dot = View(this)
            dot.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                if (key == current) {
                    setColor(palette.accent)
                    setStroke(5.dp, palette.surface2)
                } else {
                    setColor(Color.TRANSPARENT)
                    setStroke(2.dp, palette.sub)
                }
            }
            row.addView(dot, LinearLayout.LayoutParams(22.dp, 22.dp))
            row.setOnClickListener {
                if (key != prefs.getString("viewMode", "auto")) {
                    prefs.edit().putString("viewMode", key).apply()
                    applyUserAgentToAll()
                    openSettings(animate = false, keepScroll = true)
                }
            }
            modes.addView(row)
        }
        col.addView(modes)

        // Shops
        col.addView(sectionTitle("Ana sayfadaki mağazalar"))
        val list = card()
        for ((index, shop) in shops.withIndex()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, 4.dp, 0, 4.dp)
            val texts = LinearLayout(this)
            texts.orientation = LinearLayout.VERTICAL
            texts.addView(label(shop.name, 16f, palette.text, "sans-serif-medium"))
            texts.addView(label(hostOf(shop.url).removePrefix("www."), 12f, palette.sub))
            row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))
            val upBtn = iconButton(R.drawable.ic_up, "Yukarı", if (index > 0) palette.text else palette.divider) {
                if (index > 0) {
                    shops.removeAt(index)
                    shops.add(index - 1, shop)
                    saveShops(); fillGrid(); refreshSettingsIfOpen()
                }
            }
            val downBtn = iconButton(R.drawable.ic_down, "Aşağı", if (index < shops.size - 1) palette.text else palette.divider) {
                if (index < shops.size - 1) {
                    shops.removeAt(index)
                    shops.add(index + 1, shop)
                    saveShops(); fillGrid(); refreshSettingsIfOpen()
                }
            }
            val delBtn = iconButton(R.drawable.ic_close, "Kaldır", palette.sub) {
                removeShop(shop)
                saveShops(); fillGrid(); refreshSettingsIfOpen()
            }
            row.addView(upBtn, LinearLayout.LayoutParams(44.dp, 44.dp))
            row.addView(downBtn, LinearLayout.LayoutParams(44.dp, 44.dp))
            row.addView(delBtn, LinearLayout.LayoutParams(44.dp, 44.dp))
            list.addView(row)
        }
        if (shops.isEmpty()) list.addView(label("Ana sayfada mağaza yok. Aşağıdan ekleyin.", 14f, palette.sub))
        list.addView(actionRow("Mağaza ekle", "Adını ve web adresini yazmanız yeterli", palette.accent) { showAddShopDialog() })
        list.addView(actionRow("Hazır mağaza listesini geri yükle", "Eklediğiniz mağazalar korunur") {
            val existing = shops.map { it.id }.toSet()
            for (d in defaultShops()) if (d.id !in existing) shops.add(d)
            saveShops(); fillGrid(); refreshSettingsIfOpen()
            toast("Hazır mağazalar geri geldi")
        })
        col.addView(list)

        // Accounts & data
        col.addView(sectionTitle("Hesaplar ve veriler"))
        val data = card()
        data.addView(actionRow("Önbelleği temizle", "Sayfalar düzgün yüklenmezse işe yarar, hesaplarınız açık kalır") {
            val w = activeWeb ?: spare ?: webViews.values.firstOrNull()
            if (w != null) w.clearCache(true) else WebView(this).apply { clearCache(true); destroy() }
            toast("Önbellek temizlendi")
        })
        data.addView(actionRow("Tüm mağaza hesaplarından çıkış yap", "Giriş bilgileri, sepet çerezleri ve site verileri silinir", c(0xFFE5484D)) {
            dialogBuilder()
                .setTitle("Tüm hesaplardan çıkılsın mı?")
                .setMessage("Bütün mağazalarda yeniden giriş yapmanız gerekecek.")
                .setPositiveButton("Çıkış yap") { _, _ -> signOutEverywhere() }
                .setNegativeButton("Vazgeç", null)
                .show()
        })
        col.addView(data)

        @Suppress("DEPRECATION")
        val version = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
        col.addView(label("Online AVM $version", 13f, palette.sub).apply {
            gravity = Gravity.CENTER
            setPadding(0, 28.dp, 0, 0)
        }, LinearLayout.LayoutParams(MATCH, WRAP))

        scroll.addView(col)
        layer.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        root.addView(layer, match())
        settingsLayer = layer
        settingsScroll = scroll
        if (oldScroll > 0) scroll.post { scroll.scrollTo(0, oldScroll) }

        if (animate) {
            layer.alpha = 0f
            layer.translationX = 30.dp.toFloat()
            layer.animate().alpha(1f).translationX(0f).setDuration(190).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun closeSettings() {
        val l = settingsLayer ?: return
        settingsLayer = null
        settingsScroll = null
        l.animate().alpha(0f).translationX(30.dp.toFloat()).setDuration(160).withEndAction { root.removeView(l) }.start()
    }

    private fun signOutEverywhere() {
        closePopup(null)
        for (w in webViews.values) {
            (w.parent as? ViewGroup)?.removeView(w)
            try { w.destroy() } catch (e: Exception) { }
        }
        webViews.clear()
        activeWeb = null
        currentShop = null
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        toast("Tüm hesaplardan çıkış yapıldı")
    }
}
