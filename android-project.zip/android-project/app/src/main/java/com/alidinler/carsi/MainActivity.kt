package com.alidinler.carsi

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.text.InputType
import android.text.TextUtils
import android.util.LruCache
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.view.animation.DecelerateInterpolator
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.RenderProcessGoneDetail
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSession.NavigationDelegate.LoadRequest
import org.mozilla.geckoview.GeckoSession.PromptDelegate.AlertPrompt
import org.mozilla.geckoview.GeckoSession.PromptDelegate.ButtonPrompt
import org.mozilla.geckoview.GeckoSession.PromptDelegate.ChoicePrompt
import org.mozilla.geckoview.GeckoSession.PromptDelegate.PromptResponse
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.StorageController
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.concurrent.Executors

data class Shop(val id: String, val name: String, val url: String)

data class Palette(
    val key: String,
    val label: String,
    val bg: Int,
    val surface: Int,
    val surface2: Int,
    val text: Int,
    val sub: Int,
    val accent: Int,
    val divider: Int,
    val light: Boolean
)

class MainActivity : Activity() {

    companion object {
        private const val REQ_FILE = 4711
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

        private fun c(hex: Long): Int = hex.toInt()

        val PALETTES = listOf(
            Palette("black", "Siyah", c(0xFF000000), c(0xFF17171A), c(0xFF232328), Color.WHITE, c(0xFF9C9CA6), c(0xFFF2B33D), c(0xFF2A2A30), false),
            Palette("white", "Beyaz", c(0xFFFFFFFF), c(0xFFF1F2F5), c(0xFFE4E6EB), c(0xFF14161B), c(0xFF6A7079), c(0xFFC9771A), c(0xFFE2E4E9), true),
            Palette("navy", "Koyu mavi", c(0xFF0A1A36), c(0xFF13284D), c(0xFF1B3561), Color.WHITE, c(0xFFA3B5D4), c(0xFF5EE6D8), c(0xFF213C6B), false),
            Palette("maroon", "Koyu kırmızı", c(0xFF3D0A12), c(0xFF55121C), c(0xFF681A26), Color.WHITE, c(0xFFDDAAB1), c(0xFFF2B33D), c(0xFF6E1F2B), false)
        )

        // Ad and tracking servers that only slow shopping pages down. Sign-in and payment servers are never on this list.
        val BLOCKED_HOSTS = arrayOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "google-analytics.com",
            "googletagmanager.com", "googletagservices.com", "adservice.google.com", "analytics.google.com",
            "hotjar.com", "hotjar.io", "criteo.com", "criteo.net", "taboola.com", "outbrain.com",
            "clarity.ms", "bat.bing.com", "scorecardresearch.com", "adnxs.com", "rubiconproject.com",
            "pubmatic.com", "amazon-adsystem.com", "useinsider.com", "branch.io", "appsflyer.com",
            "onelink.me", "adjust.com", "onesignal.com", "analytics.tiktok.com", "ct.pinterest.com",
            "sc-static.net", "mc.yandex.ru", "mc.yandex.com", "mc.yandex.com.tr", "nr-data.net",
            "smartlook.com", "mouseflow.com", "crazyegg.com", "quantserve.com", "mixpanel.com"
        )

        // Makes pages behave like an app: no grey tap flashes, no "download our app" banners.
        const val APP_FEEL_JS = """
(function(){
  if (window.__oavm) return; window.__oavm = 1;
  var css = '*{-webkit-tap-highlight-color:transparent!important}' +
    'body{-webkit-touch-callout:none}' +
    '[class*="smart-banner"],[id*="smart-banner"],[class*="smartbanner"],[id*="smartbanner"],' +
    '[class*="app-banner"],[id*="app-banner"],[class*="appBanner"],[id*="appBanner"],' +
    '[class*="open-in-app"],[class*="openInApp"],[class*="download-app"],[class*="downloadApp"],' +
    '[class*="app-download"]{display:none!important}';
  function add(){
    var host = document.head || document.documentElement;
    if (!host) return false;
    var st = document.createElement('style'); st.textContent = css; host.appendChild(st); return true;
  }
  if (!add()) document.addEventListener('DOMContentLoaded', add);
})();
"""

        // Reads the colour at the very top of the page so the status bar can blend into the shop's own header.
        const val TOP_COLOR_JS = """
(function(){
  try {
    var e = document.elementFromPoint(window.innerWidth / 2, 3);
    while (e) {
      var c = getComputedStyle(e).backgroundColor;
      if (c && c !== 'transparent' && c.replace(/ /g, '') !== 'rgba(0,0,0,0)') return c;
      e = e.parentElement;
    }
    var m = document.querySelector('meta[name="theme-color"]');
    return m ? m.content : '';
  } catch (x) { return ''; }
})()
"""

        val LETTER_COLORS = intArrayOf(
            c(0xFFE8590C), c(0xFF1C7ED6), c(0xFF2F9E44), c(0xFFC2255C),
            c(0xFF7048E8), c(0xFF0C8599), c(0xFFE67700), c(0xFFD6336C)
        )
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var palette: Palette
    private var shops = mutableListOf<Shop>()

    private lateinit var root: FrameLayout
    private lateinit var homeLayer: FrameLayout
    private lateinit var gridBox: LinearLayout
    private lateinit var shopLayer: FrameLayout
    private lateinit var progress: ProgressBar
    private lateinit var webHolder: FrameLayout
    private lateinit var cover: LinearLayout
    private lateinit var coverIcon: ImageView
    private lateinit var coverLetter: TextView
    private lateinit var coverName: TextView
    private lateinit var bubble: FrameLayout

    private var settingsLayer: View? = null
    private var settingsScroll: ScrollView? = null

    private val webViews = LinkedHashMap<String, WebView>(8, 0.75f, true)
    private var activeWeb: WebView? = null

    // Shops that use Google sign-in run on the Firefox engine, because Google refuses sign-in inside the normal Android web view.
    private val geckoPages = LinkedHashMap<String, GeckoPage>(4, 0.75f, true)
    private var activeGecko: GeckoPage? = null
    private var geckoPopupSession: GeckoSession? = null
    private var geckoPopupView: GeckoView? = null
    private var geckoPopupBox: View? = null
    private var geckoPopupTitle: TextView? = null
    private var geckoPopupCanGoBack = false
    private var spare: WebView? = null
    private var currentShop: Shop? = null

    private var popupWeb: WebView? = null
    private var popupBox: View? = null
    private var popupTitle: TextView? = null

    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val painted = HashSet<WebView>()
    private val siteColors = HashMap<WebView, Int>()
    @Volatile private var blockTrackers = true
    private var progressPending = false

    private var downX = 0f
    private var downY = 0f
    private var startX = 0f
    private var startY = 0f
    private var dragging = false
    private var longPressed = false

    private val main = Handler(Looper.getMainLooper())
    private val ioPool = Executors.newFixedThreadPool(4)
    private val iconCache = LruCache<String, Bitmap>(80)

    private val Int.dp: Int get() = (this * resources.displayMetrics.density + 0.5f).toInt()

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("carsi", MODE_PRIVATE)
        palette = PALETTES.firstOrNull { it.key == prefs.getString("bg", "black") } ?: PALETTES[0]
        blockTrackers = prefs.getBoolean("block", true)
        loadShops()
        CookieManager.getInstance().setAcceptCookie(true)

        root = FrameLayout(this)
        setContentView(root)
        buildUi()

        // Prepare the web engine in the background so the first shop opens instantly,
        // then quietly load the first shops on the home screen so they open with no waiting.
        main.postDelayed({ prewarm() }, 300)
        main.postDelayed({ preloadTopShops() }, 1500)
        main.postDelayed({
            if (geckoIds().isNotEmpty() && !isFinishing) {
                try { geckoRuntime() } catch (e: Throwable) { }
            }
        }, 2500)
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
        activeWeb?.onPause()
        activeGecko?.session?.setActive(false)
    }

    override fun onResume() {
        super.onResume()
        if (::shopLayer.isInitialized && shopLayer.visibility == View.VISIBLE) {
            activeWeb?.onResume()
            activeGecko?.session?.setActive(true)
        }
    }

    override fun onDestroy() {
        closePopup(null)
        closeGeckoPopup()
        for (g in geckoPages.values) g.close()
        geckoPages.clear()
        for (w in webViews.values) {
            try { w.destroy() } catch (e: Exception) { }
        }
        webViews.clear()
        spare?.destroy()
        spare = null
        ioPool.shutdownNow()
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::gridBox.isInitialized) fillGrid()
        if (::bubble.isInitialized) shopLayer.post { placeBubble() }
        if (settingsLayer != null) openSettings(animate = false, keepScroll = true)
    }

    @Deprecated("Uses the classic back handling on purpose")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val pw = popupWeb
        val gp = geckoPopupSession
        when {
            settingsLayer != null -> closeSettings()
            gp != null -> if (geckoPopupCanGoBack) gp.goBack() else closeGeckoPopup()
            pw != null -> if (pw.canGoBack()) pw.goBack() else closePopup(null)
            shopLayer.visibility == View.VISIBLE -> {
                val g = activeGecko
                val w = activeWeb
                if (g != null) {
                    if (g.canGoBack) g.session.goBack() else goHome()
                } else if (w != null && w.canGoBack()) {
                    w.goBack()
                } else {
                    goHome()
                }
            }
            else -> super.onBackPressed()
        }
    }

    @Deprecated("Needed for the web page file picker")
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_FILE) {
            fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCallback = null
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    // ------------------------------------------------------------------ data

    private fun defaultShops(): List<Shop> = listOf(
        Shop("trendyol", "Trendyol", "https://www.trendyol.com"),
        Shop("hepsiburada", "Hepsiburada", "https://www.hepsiburada.com"),
        Shop("amazon", "Amazon", "https://www.amazon.com.tr"),
        Shop("n11", "n11", "https://www.n11.com"),
        Shop("ciceksepeti", "Çiçeksepeti", "https://www.ciceksepeti.com"),
        Shop("pazarama", "Pazarama", "https://www.pazarama.com"),
        Shop("temu", "Temu", "https://www.temu.com"),
        Shop("aliexpress", "AliExpress", "https://www.aliexpress.com"),
        Shop("migros", "Migros", "https://www.migros.com.tr"),
        Shop("a101", "A101", "https://www.a101.com.tr"),
        Shop("yemeksepeti", "Yemeksepeti", "https://www.yemeksepeti.com"),
        Shop("lcw", "LC Waikiki", "https://www.lcw.com"),
        Shop("defacto", "DeFacto", "https://www.defacto.com.tr"),
        Shop("boyner", "Boyner", "https://www.boyner.com.tr"),
        Shop("teknosa", "Teknosa", "https://www.teknosa.com"),
        Shop("mediamarkt", "MediaMarkt", "https://www.mediamarkt.com.tr"),
        Shop("vatan", "Vatan Bilgisayar", "https://www.vatanbilgisayar.com"),
        Shop("decathlon", "Decathlon", "https://www.decathlon.com.tr"),
        Shop("ikea", "IKEA", "https://www.ikea.com.tr"),
        Shop("koctas", "Koçtaş", "https://www.koctas.com.tr"),
        Shop("gratis", "Gratis", "https://www.gratis.com"),
        Shop("watsons", "Watsons", "https://www.watsons.com.tr"),
        Shop("sahibinden", "Sahibinden", "https://www.sahibinden.com"),
        Shop("dolap", "Dolap", "https://dolap.com")
    )

    private fun loadShops() {
        val raw = prefs.getString("shops", null)
        if (raw == null) {
            shops = defaultShops().toMutableList()
            return
        }
        val list = mutableListOf<Shop>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(Shop(o.getString("id"), o.getString("name"), o.getString("url")))
            }
        } catch (e: Exception) {
            list.clear()
            list.addAll(defaultShops())
        }
        shops = list
    }

    private fun saveShops() {
        val arr = JSONArray()
        for (s in shops) {
            arr.put(JSONObject().put("id", s.id).put("name", s.name).put("url", s.url))
        }
        prefs.edit().putString("shops", arr.toString()).apply()
    }

    // ------------------------------------------------------------------ small helpers

    private fun isTablet(): Boolean = resources.configuration.smallestScreenWidthDp >= 600

    private fun withAlpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha shl 24)

    private fun rounded(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun csl(color: Int): ColorStateList = ColorStateList.valueOf(color)

    private fun match(): FrameLayout.LayoutParams = FrameLayout.LayoutParams(MATCH, MATCH)

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun label(s: String, size: Float, color: Int, family: String = "sans-serif", style: Int = Typeface.NORMAL): TextView =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            typeface = Typeface.create(family, style)
            includeFontPadding = true
        }

    private fun iconButton(res: Int, desc: String, tint: Int = palette.text, onClick: () -> Unit): ImageView =
        ImageView(this).apply {
            setImageResource(res)
            imageTintList = csl(tint)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(12.dp, 12.dp, 12.dp, 12.dp)
            background = RippleDrawable(csl(withAlpha(palette.text, 0x33)), null, null)
            contentDescription = desc
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }

    private fun hostOf(url: String): String = Uri.parse(url).host ?: url

    private fun letterColor(name: String): Int = LETTER_COLORS[(name.hashCode() and 0x7FFFFFFF) % LETTER_COLORS.size]

    private fun dialogBuilder(): AlertDialog.Builder =
        AlertDialog.Builder(
            this,
            if (palette.light) android.R.style.Theme_DeviceDefault_Light_Dialog_Alert
            else android.R.style.Theme_DeviceDefault_Dialog_Alert
        )

    private fun greeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (h) {
            in 5..11 -> "Günaydın"
            in 12..17 -> "İyi günler"
            in 18..22 -> "İyi akşamlar"
            else -> "İyi geceler"
        }
    }

    private fun applySystemBars() = setBars(palette.bg, palette.bg)

    private fun isLightColor(c: Int): Boolean =
        (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0 > 0.6

    @Suppress("DEPRECATION")
    private fun setBars(status: Int, nav: Int) {
        window.statusBarColor = status
        window.navigationBarColor = nav
        val lightStatus = isLightColor(status)
        val lightNav = isLightColor(nav)
        if (Build.VERSION.SDK_INT >= 30) {
            val both = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            var value = 0
            if (lightStatus) value = value or WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
            if (lightNav) value = value or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            window.insetsController?.setSystemBarsAppearance(value, both)
        } else {
            var f = window.decorView.systemUiVisibility
            f = if (lightStatus) f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            f = if (lightNav) f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else f and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
            window.decorView.systemUiVisibility = f
        }
    }

    private fun applyShopBars() {
        if (activeGecko != null) {
            setBars(Color.WHITE, Color.WHITE)
            return
        }
        val w = activeWeb ?: return
        val c = siteColors[w] ?: Color.WHITE
        setBars(c, Color.WHITE)
    }

    private fun parseCssColor(raw: String?): Int? {
        if (raw == null) return null
        var s = raw.trim().trim('"').trim().lowercase()
        if (s.isEmpty() || s == "null") return null
        try {
            if (s.startsWith("#")) {
                if (s.length == 4) s = "#" + s[1] + s[1] + s[2] + s[2] + s[3] + s[3]
                return if (s.length == 7) Color.parseColor(s) else null
            }
            if (s.startsWith("rgb")) {
                val nums = Regex("[0-9.]+").findAll(s).map { it.value.toFloat() }.toList()
                if (nums.size >= 3) {
                    if (nums.size >= 4 && nums[3] < 0.5f) return null
                    return Color.rgb(nums[0].toInt(), nums[1].toInt(), nums[2].toInt())
                }
            }
        } catch (e: Exception) {
        }
        return null
    }

    private fun readSiteColor(view: WebView) {
        try {
            view.evaluateJavascript(TOP_COLOR_JS) { res ->
                val c = parseCssColor(res) ?: return@evaluateJavascript
                siteColors[view] = c
                if (view === activeWeb && shopLayer.visibility == View.VISIBLE && popupWeb == null) applyShopBars()
            }
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------ icons (each shop's own site icon)

    private fun loadIcon(url: String, onReady: (Bitmap) -> Unit) {
        val host = hostOf(url)
        val cached = iconCache.get(host)
        if (cached != null) {
            onReady(cached)
            return
        }
        ioPool.execute {
            var bmp: Bitmap? = null
            val file = File(cacheDir, "icons/$host.png")
            if (file.exists()) bmp = BitmapFactory.decodeFile(file.path)
            if (bmp == null) {
                try {
                    val conn = URL("https://www.google.com/s2/favicons?domain=$host&sz=128").openConnection() as HttpURLConnection
                    conn.connectTimeout = 7000
                    conn.readTimeout = 7000
                    val bytes = conn.inputStream.use { it.readBytes() }
                    conn.disconnect()
                    val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (decoded != null && decoded.width >= 32) {
                        bmp = decoded
                        file.parentFile?.mkdirs()
                        file.writeBytes(bytes)
                    }
                } catch (e: Exception) {
                }
            }
            val result = bmp
            if (result != null) {
                iconCache.put(host, result)
                main.post { onReady(result) }
            }
        }
    }

    // ------------------------------------------------------------------ UI building

    private fun buildUi() {
        root.removeAllViews()
        settingsLayer = null
        settingsScroll = null
        root.setBackgroundColor(palette.bg)
        window.decorView.setBackgroundColor(palette.bg)

        homeLayer = buildHome()
        root.addView(homeLayer, match())

        shopLayer = buildShopLayer()
        shopLayer.visibility = View.GONE
        root.addView(shopLayer, match())

        applySystemBars()
    }

    private fun buildHome(): FrameLayout {
        val layer = FrameLayout(this)
        layer.setBackgroundColor(palette.bg)

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.isVerticalScrollBarEnabled = false

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val side = if (isTablet()) 34.dp else 14.dp
        col.setPadding(side, if (isTablet()) 30.dp else 18.dp, side, 32.dp)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(6.dp, 0, 0, 0)

        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.addView(label(greeting(), if (isTablet()) 17f else 15f, palette.sub))
        val title = label("Online AVM", if (isTablet()) 46f else 38f, palette.text, "sans-serif-black")
        title.letterSpacing = -0.02f
        titles.addView(title)
        titles.addView(label("Bugün hangi mağazaya giriyoruz?", if (isTablet()) 17f else 15f, palette.sub))
        header.addView(titles, LinearLayout.LayoutParams(0, WRAP, 1f))

        header.addView(iconButton(R.drawable.ic_settings, "Ayarlar") { openSettings(animate = true) },
            LinearLayout.LayoutParams(52.dp, 52.dp))
        col.addView(header)

        // Thin gold rule under the title: the one decorative touch on the home screen.
        val rule = View(this)
        rule.background = rounded(palette.accent, 2.dp.toFloat())
        col.addView(rule, LinearLayout.LayoutParams(44.dp, 4.dp).apply {
            topMargin = 14.dp; bottomMargin = 18.dp; leftMargin = 6.dp
        })

        gridBox = LinearLayout(this)
        gridBox.orientation = LinearLayout.VERTICAL
        col.addView(gridBox, LinearLayout.LayoutParams(MATCH, WRAP))
        fillGrid()

        scroll.addView(col)
        layer.addView(scroll, match())
        return layer
    }

    private fun fillGrid() {
        gridBox.removeAllViews()
        val w = resources.configuration.screenWidthDp
        val cols = when {
            w >= 1100 -> 6
            w >= 840 -> 5
            w >= 600 -> 4
            else -> 3
        }
        val tileH = if (isTablet()) 156.dp else 122.dp
        val total = shops.size + 1
        var row: LinearLayout? = null
        for (i in 0 until total) {
            if (i % cols == 0) {
                val r = LinearLayout(this)
                r.orientation = LinearLayout.HORIZONTAL
                gridBox.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
                row = r
            }
            val tile = if (i < shops.size) shopTile(shops[i]) else addTile()
            row?.addView(tile, tileParams(tileH))
        }
        val rem = total % cols
        if (rem != 0) {
            for (k in 0 until cols - rem) row?.addView(View(this), tileParams(tileH))
        }
    }

    private fun tileParams(h: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, h, 1f).apply { setMargins(6.dp, 6.dp, 6.dp, 6.dp) }

    private fun tileBackground(): RippleDrawable =
        RippleDrawable(
            csl(withAlpha(palette.accent, 0x55)),
            rounded(palette.surface, 22.dp.toFloat()),
            rounded(Color.WHITE, 22.dp.toFloat())
        )

    private fun pressAnim(v: View) {
        v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(70).withEndAction {
            v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()
    }

    private fun shopTile(shop: Shop): View {
        val frame = FrameLayout(this)
        val tile = LinearLayout(this)
        tile.orientation = LinearLayout.VERTICAL
        tile.gravity = Gravity.CENTER
        tile.background = tileBackground()
        tile.isClickable = true
        tile.isFocusable = true
        if (palette.light) tile.elevation = 1.5f * resources.displayMetrics.density

        val box = FrameLayout(this)
        box.background = rounded(Color.WHITE, 16.dp.toFloat())
        val letter = label(shop.name.take(1).uppercase(), if (isTablet()) 28f else 24f, letterColor(shop.name), "sans-serif-black")
        letter.gravity = Gravity.CENTER
        box.addView(letter, FrameLayout.LayoutParams(MATCH, MATCH))
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        img.visibility = View.GONE
        val pad = if (isTablet()) 12.dp else 10.dp
        box.addView(img, FrameLayout.LayoutParams(MATCH, MATCH).apply { setMargins(pad, pad, pad, pad) })
        val boxSize = if (isTablet()) 68.dp else 54.dp
        tile.addView(box, LinearLayout.LayoutParams(boxSize, boxSize))

        val name = label(shop.name, if (isTablet()) 16f else 13f, palette.text, "sans-serif-medium")
        name.gravity = Gravity.CENTER
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        tile.addView(name, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            topMargin = if (isTablet()) 14.dp else 10.dp; leftMargin = 6.dp; rightMargin = 6.dp
        })

        loadIcon(shop.url) { bmp ->
            img.setImageBitmap(bmp)
            img.visibility = View.VISIBLE
            letter.visibility = View.GONE
        }

        tile.setOnClickListener {
            pressAnim(frame)
            openShop(shop, animate = true)
        }
        tile.setOnLongClickListener {
            tileMenu(shop)
            true
        }
        frame.addView(tile, match())

        // Small dot = this shop is already open and will appear instantly.
        if (webViews.containsKey(shop.id) || geckoPages.containsKey(shop.id)) {
            val dot = View(this)
            dot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(palette.accent) }
            frame.addView(dot, FrameLayout.LayoutParams(9.dp, 9.dp).apply {
                gravity = Gravity.TOP or Gravity.END
                topMargin = 12.dp
                rightMargin = 12.dp
            })
        }
        return frame
    }

    private fun addTile(): View {
        val tile = LinearLayout(this)
        tile.orientation = LinearLayout.VERTICAL
        tile.gravity = Gravity.CENTER
        val bg = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            cornerRadius = 22.dp.toFloat()
            setStroke(2.dp, palette.divider, 10.dp.toFloat(), 6.dp.toFloat())
        }
        tile.background = RippleDrawable(csl(withAlpha(palette.accent, 0x55)), bg, rounded(Color.WHITE, 22.dp.toFloat()))
        tile.isClickable = true
        val plus = ImageView(this)
        plus.setImageResource(R.drawable.ic_add)
        plus.imageTintList = csl(palette.sub)
        tile.addView(plus, LinearLayout.LayoutParams(34.dp, 34.dp))
        tile.addView(label("Mağaza ekle", if (isTablet()) 15f else 13f, palette.sub, "sans-serif-medium").apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = 8.dp })
        tile.setOnClickListener {
            pressAnim(it)
            showAddShopDialog()
        }
        return tile
    }

    private fun buildShopLayer(): FrameLayout {
        val layer = FrameLayout(this)
        layer.setBackgroundColor(Color.WHITE)

        webHolder = FrameLayout(this)
        webHolder.setBackgroundColor(Color.WHITE)
        layer.addView(webHolder, match())

        // Loading screen with the shop's logo, shown only the first time a shop opens.
        cover = LinearLayout(this)
        cover.orientation = LinearLayout.VERTICAL
        cover.gravity = Gravity.CENTER
        cover.setBackgroundColor(Color.WHITE)
        cover.isClickable = true
        val logoBox = FrameLayout(this)
        logoBox.background = rounded(Color.WHITE, 28.dp.toFloat())
        logoBox.elevation = 4.dp.toFloat()
        coverLetter = label("", 44f, Color.DKGRAY, "sans-serif-black")
        coverLetter.gravity = Gravity.CENTER
        logoBox.addView(coverLetter, match())
        coverIcon = ImageView(this)
        coverIcon.scaleType = ImageView.ScaleType.FIT_CENTER
        logoBox.addView(coverIcon, FrameLayout.LayoutParams(MATCH, MATCH).apply { setMargins(18.dp, 18.dp, 18.dp, 18.dp) })
        cover.addView(logoBox, LinearLayout.LayoutParams(110.dp, 110.dp))
        coverName = label("", 20f, c(0xFF2B2E35), "sans-serif-medium")
        coverName.gravity = Gravity.CENTER
        cover.addView(coverName, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = 20.dp })
        val spinner = ProgressBar(this)
        spinner.indeterminateTintList = csl(palette.accent)
        cover.addView(spinner, LinearLayout.LayoutParams(30.dp, 30.dp).apply { topMargin = 26.dp })
        cover.visibility = View.GONE
        layer.addView(cover, match())

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 100
        progress.isIndeterminate = false
        progress.progressTintList = csl(palette.accent)
        progress.progressBackgroundTintList = csl(Color.TRANSPARENT)
        progress.alpha = 0f
        layer.addView(progress, FrameLayout.LayoutParams(MATCH, 3.dp).apply { gravity = Gravity.TOP })

        bubble = buildBubble()
        layer.addView(bubble, FrameLayout.LayoutParams(50.dp, 50.dp))
        layer.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> placeBubble() }
        return layer
    }

    // ------------------------------------------------------------------ floating home button

    @SuppressLint("ClickableViewAccessibility")
    private fun buildBubble(): FrameLayout {
        val b = FrameLayout(this)
        b.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(withAlpha(palette.bg, 0xEE))
            setStroke(1.dp, withAlpha(palette.accent, 0x99))
        }
        b.elevation = 8.dp.toFloat()
        b.contentDescription = "Ana sayfa"
        val icon = ImageView(this)
        icon.setImageResource(R.drawable.ic_apps)
        icon.imageTintList = csl(palette.accent)
        b.addView(icon, FrameLayout.LayoutParams(24.dp, 24.dp).apply { gravity = Gravity.CENTER })
        b.alpha = 0.6f

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        val longPress = Runnable {
            longPressed = true
            b.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
            reloadActive()
            toast("Sayfa yenileniyor")
        }
        b.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = v.x; startY = v.y
                    dragging = false; longPressed = false
                    main.removeCallbacks(bubbleIdle)
                    v.animate().cancel()
                    v.alpha = 1f
                    v.scaleX = 0.9f; v.scaleY = 0.9f
                    main.postDelayed(longPress, 550)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && Math.hypot(dx.toDouble(), dy.toDouble()) > slop) {
                        dragging = true
                        main.removeCallbacks(longPress)
                    }
                    if (dragging) {
                        v.x = clampX(startX + dx)
                        v.y = clampY(startY + dy)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    main.removeCallbacks(longPress)
                    v.scaleX = 1f; v.scaleY = 1f
                    if (dragging) snapBubble()
                    else if (!longPressed) goHome()
                    scheduleBubbleIdle()
                }
                MotionEvent.ACTION_CANCEL -> {
                    main.removeCallbacks(longPress)
                    v.scaleX = 1f; v.scaleY = 1f
                    if (dragging) snapBubble()
                    scheduleBubbleIdle()
                }
            }
            true
        }
        return b
    }

    private val bubbleIdle = Runnable {
        if (::bubble.isInitialized) bubble.animate().alpha(0.45f).setDuration(400).start()
    }

    private fun scheduleBubbleIdle() {
        main.removeCallbacks(bubbleIdle)
        main.postDelayed(bubbleIdle, 2500)
    }

    private fun clampX(x: Float): Float {
        val max = (shopLayer.width - bubble.width - 6.dp).toFloat()
        return Math.max(6.dp.toFloat(), Math.min(x, max))
    }

    private fun clampY(y: Float): Float {
        val max = (shopLayer.height - bubble.height - 10.dp).toFloat()
        return Math.max(10.dp.toFloat(), Math.min(y, max))
    }

    private fun placeBubble() {
        if (!::bubble.isInitialized || shopLayer.width == 0 || dragging) return
        val right = prefs.getBoolean("bubbleRight", true)
        val ratio = prefs.getFloat("bubbleY", 0.62f)
        val size = if (bubble.width > 0) bubble.width else 50.dp
        bubble.x = if (right) (shopLayer.width - size - 6.dp).toFloat() else 6.dp.toFloat()
        bubble.y = clampY(shopLayer.height * ratio)
    }

    private fun snapBubble() {
        val right = bubble.x + bubble.width / 2f > shopLayer.width / 2f
        val targetX = if (right) (shopLayer.width - bubble.width - 6.dp).toFloat() else 6.dp.toFloat()
        bubble.animate().x(targetX).setDuration(180).setInterpolator(DecelerateInterpolator()).start()
        val ratio = if (shopLayer.height > 0) bubble.y / shopLayer.height else 0.62f
        prefs.edit().putBoolean("bubbleRight", right).putFloat("bubbleY", ratio).apply()
    }

    // ------------------------------------------------------------------ loading screen

    private val hideCoverRunnable = Runnable { hideCover() }

    private fun showCover(shop: Shop) {
        coverName.text = shop.name
        coverLetter.text = shop.name.take(1).uppercase()
        coverLetter.setTextColor(letterColor(shop.name))
        coverLetter.visibility = View.VISIBLE
        coverIcon.setImageDrawable(null)
        loadIcon(shop.url) { bmp ->
            if (currentShop?.id == shop.id) {
                coverIcon.setImageBitmap(bmp)
                coverLetter.visibility = View.GONE
            }
        }
        cover.animate().cancel()
        cover.alpha = 1f
        cover.visibility = View.VISIBLE
        main.removeCallbacks(hideCoverRunnable)
        main.postDelayed(hideCoverRunnable, 9000)
    }

    private fun hideCover() {
        main.removeCallbacks(hideCoverRunnable)
        if (cover.visibility != View.VISIBLE) return
        cover.animate().alpha(0f).setDuration(220).withEndAction { cover.visibility = View.GONE }.start()
    }

    private fun markPainted(view: WebView) {
        painted.add(view)
        if (view === activeWeb) hideCover()
    }

    // ------------------------------------------------------------------ web engine

    private fun isWide(shopId: String?): Boolean =
        shopId != null && (prefs.getStringSet("wide", emptySet()) ?: emptySet()).contains(shopId)

    private fun buildUserAgent(wide: Boolean): String {
        var ua = try { WebSettings.getDefaultUserAgent(this) } catch (e: Exception) { "" }
        if (ua.isEmpty()) {
            ua = "Mozilla/5.0 (Linux; Android ${Build.VERSION.RELEASE}; ${Build.MODEL}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        }
        // Look like the normal Chrome app (not an embedded view) so account sign-in pages, including Google's, open.
        ua = ua.replace("; wv)", ")").replace(Regex("Version/\\d+(\\.\\d+)* "), "")
        val chrome = Regex("Chrome/([\\d.]+)").find(ua)?.groupValues?.get(1) ?: "124.0.0.0"
        if (wide) {
            return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$chrome Safari/537.36"
        }
        // App view: the shops' touch-first mobile pages (the same layout their own apps use), stretched to the full screen.
        return if (ua.contains("Mobile Safari")) ua else ua.replace(" Safari/", " Mobile Safari/")
    }

    private fun applyShopMode(wv: WebView, shopId: String?) {
        val wide = isWide(shopId)
        val s = wv.settings
        s.userAgentString = buildUserAgent(wide)
        s.setSupportZoom(wide)
        s.builtInZoomControls = wide
        s.displayZoomControls = false
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(wv: WebView, shopId: String?) {
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportMultipleWindows(true)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.loadsImagesAutomatically = true
        s.mediaPlaybackRequiresUserGesture = true
        s.offscreenPreRaster = true
        s.textZoom = 100
        applyShopMode(wv, shopId)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        hideRequestedWithHeader(s)
        addAppFeelScript(wv)
        wv.setBackgroundColor(Color.WHITE)
        wv.isVerticalScrollBarEnabled = false
        wv.isHorizontalScrollBarEnabled = false
        wv.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true)
        wv.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            startDownload(url, userAgent, contentDisposition, mimetype)
        }
    }

    // Stops the page from being told it runs inside an app (helps Google sign-in). Silently skipped on old engines.
    private fun hideRequestedWithHeader(s: WebSettings) {
        try {
            val cls = Class.forName("androidx.webkit.WebSettingsCompat")
            val m = cls.getMethod("setRequestedWithHeaderOriginAllowList", WebSettings::class.java, Set::class.java)
            m.invoke(null, s, emptySet<String>())
        } catch (e: Throwable) {
        }
    }

    // Runs the app-feel script before the page's own code. Older engines get it after loading instead.
    private fun addAppFeelScript(wv: WebView) {
        try {
            val feature = Class.forName("androidx.webkit.WebViewFeature")
            val ok = feature.getMethod("isFeatureSupported", String::class.java).invoke(null, "DOCUMENT_START_SCRIPT") as Boolean
            if (!ok) return
            val compat = Class.forName("androidx.webkit.WebViewCompat")
            compat.getMethod("addDocumentStartJavaScript", WebView::class.java, String::class.java, Set::class.java)
                .invoke(null, wv, APP_FEEL_JS, setOf("*"))
        } catch (e: Throwable) {
        }
    }

    private fun injectAppFeel(view: WebView) {
        try { view.evaluateJavascript(APP_FEEL_JS, null) } catch (e: Exception) { }
    }

    private fun isBlocked(host: String): Boolean {
        val h = host.lowercase()
        for (d in BLOCKED_HOSTS) if (h == d || h.endsWith(".$d")) return true
        return false
    }

    private fun createWebView(shopId: String? = null): WebView {
        val wv = WebView(this)
        configureWebView(wv, shopId)
        wv.webViewClient = ShopClient()
        wv.webChromeClient = ShopChrome()
        return wv
    }

    private fun maxLive(): Int = if (isTablet()) 6 else 4

    private fun destroyWeb(w: WebView) {
        (w.parent as? ViewGroup)?.removeView(w)
        painted.remove(w)
        siteColors.remove(w)
        try { w.destroy() } catch (e: Exception) { }
    }

    private fun preloadTopShops() {
        if (!prefs.getBoolean("preload", true) || isFinishing || isDestroyed) return
        var delay = 0L
        for (s in shops.take(3)) {
            main.postDelayed({
                if (!isFinishing && !isDestroyed && !isGecko(s.id) && !webViews.containsKey(s.id) && webViews.size < maxLive() - 1) {
                    val wv = createWebView(s.id)
                    // Give the hidden page a real screen size so it is laid out and ready when opened.
                    val w = if (root.width > 0) root.width else resources.displayMetrics.widthPixels
                    val h = if (root.height > 0) root.height else resources.displayMetrics.heightPixels
                    wv.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                        View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY))
                    wv.layout(0, 0, w, h)
                    webViews[s.id] = wv
                    wv.loadUrl(s.url)
                    if (homeLayer.visibility == View.VISIBLE) fillGrid()
                }
            }, delay)
            delay += 1200
        }
    }

    private fun prewarm() {
        if (spare == null && !isFinishing && !isDestroyed) {
            try { spare = createWebView() } catch (e: Exception) { }
        }
    }


    private fun startDownload(url: String, userAgent: String?, contentDisposition: String?, mimetype: String?) {
        if (!url.startsWith("http")) {
            toast("Bu dosya bu şekilde indirilemiyor")
            return
        }
        try {
            val name = URLUtil.guessFileName(url, contentDisposition, mimetype)
            val req = DownloadManager.Request(Uri.parse(url))
            if (mimetype != null) req.setMimeType(mimetype)
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            if (userAgent != null) req.addRequestHeader("User-Agent", userAgent)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("İndiriliyor: $name")
        } catch (e: Exception) {
            toast("Dosya indirilemedi")
        }
    }

    /** Returns true when the link must NOT be loaded inside the page. Keeps shopping inside the app. */
    private fun handleScheme(view: WebView, uri: Uri): Boolean =
        handleSchemeWith(uri, view.url) { view.loadUrl(it) }

    private fun handleSchemeWith(uri: Uri, currentUrl: String?, load: (String) -> Unit): Boolean {
        val scheme = (uri.scheme ?: "").lowercase()
        return when (scheme) {
            "http", "https", "about", "data", "blob", "javascript" -> false
            "intent" -> {
                // Sites try to throw you into their own app; load their web fallback instead and stay here.
                try {
                    val intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                    val fb = intent.getStringExtra("browser_fallback_url")
                    if (fb != null && fb.startsWith("http") && fb != currentUrl) load(fb)
                } catch (e: Exception) {
                }
                true
            }
            "tel", "mailto", "sms", "smsto", "geo", "whatsapp" -> {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (e: Exception) {
                    toast("Bu bağlantı açılamadı")
                }
                true
            }
            else -> true
        }
    }

    private fun handleRenderGone(view: WebView) {
        if (view === popupWeb) {
            closePopup(null)
            return
        }
        if (view === spare) {
            spare = null
            try { view.destroy() } catch (e: Exception) { }
            return
        }
        var key: String? = null
        for ((k, v) in webViews) if (v === view) key = k
        destroyWeb(view)
        if (key != null) {
            webViews.remove(key)
            val cur = currentShop
            if (cur != null && cur.id == key && shopLayer.visibility == View.VISIBLE) openShop(cur, animate = false)
        }
    }

    inner class ShopClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val v = view ?: return false
            val r = request ?: return false
            val u = r.url ?: return false
            if (r.isForMainFrame && isGoogleSignIn(u)) {
                val shop = shopOf(v)
                if (shop != null) {
                    val back = v.url
                    main.post { switchToGecko(shop, back) }
                    return true
                }
            }
            return handleScheme(v, u)
        }

        override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
            if (!blockTrackers) return null
            val host = request?.url?.host ?: return null
            if (isBlocked(host)) return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            return null
        }

        override fun onPageCommitVisible(view: WebView?, url: String?) {
            val v = view ?: return
            injectAppFeel(v)
            markPainted(v)
            readSiteColor(v)
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            CookieManager.getInstance().flush()
            val v = view ?: return
            injectAppFeel(v)
            markPainted(v)
            readSiteColor(v)
            main.postDelayed({ readSiteColor(v) }, 1200)
        }

        override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
            if (view != null) main.post { handleRenderGone(view) }
            return true
        }
    }

    inner class PopupClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val v = view ?: return false
            val u = request?.url ?: return false
            if (isGoogleSignIn(u)) {
                popupGoogle(v)
                return true
            }
            return handleScheme(v, u)
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            if (url != null && view != null && isGoogleSignIn(Uri.parse(url))) {
                popupGoogle(view)
                return
            }
            if (url != null && url.startsWith("http")) popupTitle?.text = hostOf(url).removePrefix("www.")
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            CookieManager.getInstance().flush()
        }

        override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
            main.post { closePopup(null) }
            return true
        }
    }

    inner class ShopChrome : WebChromeClient() {
        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            if (view != null && view === activeWeb) updateProgress(newProgress)
        }

        // "Google ile giriş" and similar buttons open a small window: show it as a sheet inside the app.
        override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
            val msg = resultMsg ?: return false
            val popup = createPopup()
            val transport = msg.obj as WebView.WebViewTransport
            transport.webView = popup
            msg.sendToTarget()
            return true
        }

        override fun onCloseWindow(window: WebView?) {
            closePopup(window)
        }

        @Suppress("DEPRECATION")
        override fun onShowFileChooser(
            webView: WebView?,
            filePathCallback: ValueCallback<Array<Uri>>?,
            fileChooserParams: FileChooserParams?
        ): Boolean {
            fileCallback?.onReceiveValue(null)
            fileCallback = filePathCallback
            return try {
                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(intent, REQ_FILE)
                true
            } catch (e: Exception) {
                fileCallback = null
                false
            }
        }

        override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
            callback?.invoke(origin, false, false)
        }
    }

    private fun createPopup(): WebView {
        closePopup(null)
        val wv = WebView(this)
        configureWebView(wv, currentShop?.id)
        wv.webViewClient = PopupClient()
        wv.webChromeClient = ShopChrome()

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundColor(palette.bg)
        box.isClickable = true
        box.elevation = 10.dp.toFloat()

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(4.dp, 0, 12.dp, 0)
        bar.addView(iconButton(R.drawable.ic_close, "Kapat") { closePopup(null) }, LinearLayout.LayoutParams(50.dp, 50.dp))
        val title = label("Giriş", 16f, palette.sub, "sans-serif-medium")
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        bar.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        box.addView(bar, LinearLayout.LayoutParams(MATCH, 52.dp))
        box.addView(wv, LinearLayout.LayoutParams(MATCH, 0, 1f))

        webHolder.addView(box, match())
        box.alpha = 0f
        box.translationY = 40.dp.toFloat()
        box.animate().alpha(1f).translationY(0f).setDuration(200).setInterpolator(DecelerateInterpolator()).start()

        popupWeb = wv
        popupBox = box
        popupTitle = title
        setBars(palette.bg, palette.bg)
        return wv
    }

    private fun closePopup(target: WebView?) {
        val wv = popupWeb ?: return
        if (target != null && target !== wv) return
        val box = popupBox
        popupWeb = null
        popupBox = null
        popupTitle = null
        if (box != null) (box.parent as? ViewGroup)?.removeView(box)
        if (shopLayer.visibility == View.VISIBLE) applyShopBars()
        main.post {
            try {
                wv.stopLoading()
                wv.destroy()
            } catch (e: Exception) {
            }
        }
    }

    // ------------------------------------------------------------------ navigation

    private fun openShop(shop: Shop, animate: Boolean, startUrl: String? = null) {
        if (currentShop?.id != shop.id) {
            closePopup(null)
            closeGeckoPopup()
        }
        currentShop = shop
        if (isGecko(shop.id)) {
            openGeckoShop(shop, animate, startUrl)
            return
        }

        val existing = webViews[shop.id]
        val wv: WebView
        if (existing != null) {
            wv = existing
        } else {
            val sp = spare
            spare = null
            wv = if (sp != null) sp.also { applyShopMode(it, shop.id) } else createWebView(shop.id)
            webViews[shop.id] = wv
            wv.loadUrl(startUrl ?: shop.url)
            trimWebViews(shop.id)
        }

        for (g in geckoPages.values) {
            if (g.view.parent != null) {
                (g.view.parent as? ViewGroup)?.removeView(g.view)
                g.session.setActive(false)
            }
        }
        activeGecko = null

        for (other in webViews.values) {
            if (other !== wv && other.parent != null) {
                (other.parent as? ViewGroup)?.removeView(other)
                other.onPause()
            }
        }
        if (wv.parent !== webHolder) {
            (wv.parent as? ViewGroup)?.removeView(wv)
            webHolder.addView(wv, 0, match())
        }
        activeWeb = wv
        wv.onResume()

        if (painted.contains(wv)) {
            main.removeCallbacks(hideCoverRunnable)
            cover.animate().cancel()
            cover.visibility = View.GONE
        } else {
            showCover(shop)
        }
        progressPending = false
        progress.animate().cancel()
        progress.alpha = 0f

        applyShopBars()
        showShopLayer(animate)
        placeBubble()
        bubble.alpha = 1f
        scheduleBubbleIdle()

        // Keep a fresh engine ready for the next shop.
        main.postDelayed({ prewarm() }, 900)
    }

    private fun trimWebViews(keep: String) {
        while (webViews.size > maxLive()) {
            val eldest = webViews.keys.firstOrNull { it != keep } ?: break
            val w = webViews.remove(eldest) ?: break
            destroyWeb(w)
        }
    }

    private fun showShopLayer(animate: Boolean) {
        shopLayer.animate().cancel()
        shopLayer.visibility = View.VISIBLE
        if (animate) {
            shopLayer.alpha = 0f
            shopLayer.translationY = 20.dp.toFloat()
            shopLayer.animate().alpha(1f).translationY(0f).setDuration(190)
                .setInterpolator(DecelerateInterpolator())
                .withEndAction { if (shopLayer.visibility == View.VISIBLE) homeLayer.visibility = View.INVISIBLE }
                .start()
        } else {
            shopLayer.alpha = 1f
            shopLayer.translationY = 0f
            homeLayer.visibility = View.INVISIBLE
        }
    }

    private fun pageBack() {
        val pw = popupWeb
        if (pw != null) {
            if (pw.canGoBack()) pw.goBack() else closePopup(null)
            return
        }
        val w = activeWeb
        if (w != null && w.canGoBack()) w.goBack() else goHome()
    }

    private fun goHome() {
        closePopup(null)
        closeGeckoPopup()
        fillGrid()
        homeLayer.visibility = View.VISIBLE
        applySystemBars()
        shopLayer.animate().cancel()
        shopLayer.animate().alpha(0f).translationY(20.dp.toFloat()).setDuration(160)
            .withEndAction {
                shopLayer.visibility = View.GONE
                activeWeb?.onPause()
                activeGecko?.session?.setActive(false)
            }.start()
    }

    private val showProgressRunnable = Runnable {
        progressPending = false
        if (cover.visibility != View.VISIBLE) progress.animate().alpha(1f).setDuration(150).start()
    }

    // A thin line appears only when a page takes longer than a moment, like in shop apps.
    private fun updateProgress(p: Int) {
        progress.progress = p
        if (p >= 100) {
            main.removeCallbacks(showProgressRunnable)
            progressPending = false
            if (progress.alpha > 0f) progress.animate().alpha(0f).setDuration(250).start()
        } else if (progress.alpha == 0f && !progressPending) {
            progressPending = true
            main.postDelayed(showProgressRunnable, 450)
        }
    }

    // ------------------------------------------------------------------ shop management

    private fun tileMenu(shop: Shop) {
        val wide = isWide(shop.id)
        val wideLabel = if (wide) "Uygulama görünümüne dön" else "Geniş görünümde aç (bilgisayar sayfası)"
        val gecko = isGecko(shop.id)
        val geckoLabel = if (gecko) "Hızlı motora dön (Google ile giriş çalışmaz)" else "Google ile giriş modunda aç (Firefox motoru)"
        dialogBuilder()
            .setTitle(shop.name)
            .setItems(arrayOf("En başa taşı", wideLabel, geckoLabel, "Ana sayfadan kaldır")) { _, which ->
                when (which) {
                    0 -> {
                        shops.remove(shop)
                        shops.add(0, shop)
                    }
                    1 -> {
                        val set = HashSet(prefs.getStringSet("wide", emptySet()) ?: emptySet())
                        if (wide) set.remove(shop.id) else set.add(shop.id)
                        prefs.edit().putStringSet("wide", set).apply()
                        webViews[shop.id]?.let { w ->
                            applyShopMode(w, shop.id)
                            w.loadUrl(shop.url)
                        }
                        geckoPages.remove(shop.id)?.close()
                        if (activeGecko?.shopId == shop.id) activeGecko = null
                        toast(if (wide) "${shop.name} uygulama görünümünde açılacak" else "${shop.name} geniş görünümde açılacak")
                    }
                    2 -> {
                        setGecko(shop.id, !gecko)
                        dropShopPages(shop.id)
                        toast(if (gecko) "${shop.name} hızlı motorla açılacak" else "${shop.name} Google ile giriş modunda açılacak")
                    }
                    3 -> removeShop(shop)
                }
                saveShops()
                fillGrid()
            }
            .show()
    }

    private fun removeShop(shop: Shop) {
        shops.remove(shop)
        dropShopPages(shop.id)
        if (currentShop?.id == shop.id) currentShop = null
    }

    private fun dropShopPages(id: String) {
        webViews.remove(id)?.let { w ->
            if (w === activeWeb) activeWeb = null
            destroyWeb(w)
        }
        geckoPages.remove(id)?.let { g ->
            if (g === activeGecko) activeGecko = null
            g.close()
        }
    }

    private fun reloadActive() {
        val g = activeGecko
        if (g != null) g.session.reload() else activeWeb?.reload()
    }

    // ------------------------------------------------------------------ Google sign-in → Firefox engine

    private fun isGoogleSignIn(u: Uri): Boolean =
        (u.scheme ?: "").startsWith("http") && u.host?.lowercase() == "accounts.google.com"

    private fun shopOf(view: WebView): Shop? {
        var key: String? = null
        for ((k, v) in webViews) if (v === view) key = k
        val id = key ?: return null
        return shops.firstOrNull { it.id == id }
    }

    private fun popupGoogle(view: WebView) {
        try { view.stopLoading() } catch (e: Exception) { }
        val shop = currentShop ?: return
        val back = activeWeb?.url
        main.post { switchToGecko(shop, back) }
    }

    private fun switchToGecko(shop: Shop, returnUrl: String?) {
        if (isGecko(shop.id)) return
        setGecko(shop.id, true)
        closePopup(null)
        webViews.remove(shop.id)?.let { w ->
            if (w === activeWeb) activeWeb = null
            destroyWeb(w)
        }
        val url = if (returnUrl != null && returnUrl.startsWith("http")) returnUrl else shop.url
        openShop(shop, animate = false, startUrl = url)
        dialogBuilder()
            .setTitle("Google ile giriş")
            .setMessage(
                "Google, hesap girişine sadece tam bir tarayıcı motorundan izin veriyor. " +
                    "Bu yüzden ${shop.name} şimdi Firefox motoruyla açıldı.\n\n" +
                    "\"Google ile giriş\" düğmesine bir kez daha dokunun. ${shop.name} bundan sonra hep bu şekilde açılacak ve girişiniz kalıcı olacak."
            )
            .setPositiveButton("Tamam", null)
            .show()
    }

    private fun geckoIds(): Set<String> = prefs.getStringSet("gecko", emptySet()) ?: emptySet()

    private fun isGecko(id: String?): Boolean = id != null && geckoIds().contains(id)

    private fun setGecko(id: String, on: Boolean) {
        val set = HashSet(geckoIds())
        if (on) set.add(id) else set.remove(id)
        prefs.edit().putStringSet("gecko", set).apply()
    }

    private fun geckoRuntime(): GeckoRuntime = GeckoRuntime.getDefault(this)

    private fun newGeckoSession(wide: Boolean): GeckoSession {
        val settings = GeckoSessionSettings.Builder()
            .usePrivateMode(false)
            .userAgentMode(if (wide) GeckoSessionSettings.USER_AGENT_MODE_DESKTOP else GeckoSessionSettings.USER_AGENT_MODE_MOBILE)
            .viewportMode(if (wide) GeckoSessionSettings.VIEWPORT_MODE_DESKTOP else GeckoSessionSettings.VIEWPORT_MODE_MOBILE)
            .build()
        return GeckoSession(settings)
    }

    inner class GeckoPage(val shopId: String, startUrl: String) {
        val session: GeckoSession = newGeckoSession(isWide(shopId))
        val view: GeckoView = GeckoView(this@MainActivity)
        var canGoBack = false
        var painted = false

        init {
            setupGeckoSession(session, this)
            session.open(geckoRuntime())
            view.setSession(session)
            session.loadUri(startUrl)
        }

        fun close() {
            (view.parent as? ViewGroup)?.removeView(view)
            try { view.releaseSession() } catch (e: Throwable) { }
            try { session.close() } catch (e: Throwable) { }
        }
    }

    private fun setupGeckoSession(session: GeckoSession, page: GeckoPage?) {
        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                if (page != null) page.canGoBack = canGoBack
                else if (session === geckoPopupSession) geckoPopupCanGoBack = canGoBack
            }

            override fun onLoadRequest(session: GeckoSession, request: LoadRequest): GeckoResult<AllowOrDeny>? {
                val uri = Uri.parse(request.uri)
                val blocked = handleSchemeWith(uri, null) { url -> main.post { session.loadUri(url) } }
                return GeckoResult.fromValue(if (blocked) AllowOrDeny.DENY else AllowOrDeny.ALLOW)
            }

            override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
                return GeckoResult.fromValue(openGeckoPopup())
            }
        }

        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                if (page == null && url.startsWith("http")) geckoPopupTitle?.text = hostOf(url).removePrefix("www.")
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                if (page != null) {
                    page.painted = true
                    if (page === activeGecko) {
                        hideCover()
                        updateProgress(100)
                    }
                }
            }

            override fun onProgressChange(session: GeckoSession, value: Int) {
                if (page != null && page === activeGecko) updateProgress(value)
            }
        }

        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onFirstContentfulPaint(session: GeckoSession) {
                if (page != null) {
                    page.painted = true
                    if (page === activeGecko) hideCover()
                }
            }

            override fun onCloseRequest(session: GeckoSession) {
                if (page == null && session === geckoPopupSession) closeGeckoPopup()
            }

            override fun onCrash(session: GeckoSession) {
                main.post { onGeckoGone(page) }
            }

        }

        session.promptDelegate = object : GeckoSession.PromptDelegate {
            override fun onAlertPrompt(session: GeckoSession, prompt: AlertPrompt): GeckoResult<PromptResponse>? {
                val result = GeckoResult<PromptResponse>()
                dialogBuilder()
                    .setTitle(prompt.title ?: "")
                    .setMessage(prompt.message ?: "")
                    .setPositiveButton("Tamam") { _, _ -> result.complete(prompt.dismiss()) }
                    .setOnCancelListener { result.complete(prompt.dismiss()) }
                    .show()
                return result
            }

            override fun onButtonPrompt(session: GeckoSession, prompt: ButtonPrompt): GeckoResult<PromptResponse>? {
                val result = GeckoResult<PromptResponse>()
                dialogBuilder()
                    .setTitle(prompt.title ?: "")
                    .setMessage(prompt.message ?: "")
                    .setPositiveButton("Tamam") { _, _ -> result.complete(prompt.confirm(ButtonPrompt.Type.POSITIVE)) }
                    .setNegativeButton("Vazgeç") { _, _ -> result.complete(prompt.confirm(ButtonPrompt.Type.NEGATIVE)) }
                    .setOnCancelListener { result.complete(prompt.dismiss()) }
                    .show()
                return result
            }

            // Drop-down lists (size, city, district...) in the shop's forms.
            override fun onChoicePrompt(session: GeckoSession, prompt: ChoicePrompt): GeckoResult<PromptResponse>? {
                val result = GeckoResult<PromptResponse>()
                val flat = ArrayList<ChoicePrompt.Choice>()
                fun collect(list: Array<ChoicePrompt.Choice>?) {
                    if (list == null) return
                    for (ch in list) {
                        val sub = ch.items
                        if (sub != null) collect(sub) else if (!ch.separator && !ch.disabled) flat.add(ch)
                    }
                }
                collect(prompt.choices)
                if (flat.isEmpty()) return GeckoResult.fromValue(prompt.dismiss())
                val labels = flat.map { it.label }.toTypedArray<CharSequence>()
                val builder = dialogBuilder()
                if (!prompt.title.isNullOrEmpty()) builder.setTitle(prompt.title)
                if (prompt.type == ChoicePrompt.Type.MULTIPLE) {
                    val checked = BooleanArray(flat.size) { flat[it].selected }
                    builder.setMultiChoiceItems(labels, checked) { _, i, on -> checked[i] = on }
                    builder.setPositiveButton("Tamam") { _, _ ->
                        val ids = ArrayList<String>()
                        for (i in flat.indices) if (checked[i]) ids.add(flat[i].id)
                        result.complete(prompt.confirm(ids.toTypedArray()))
                    }
                } else {
                    builder.setItems(labels) { _, i -> result.complete(prompt.confirm(flat[i])) }
                }
                builder.setOnCancelListener { result.complete(prompt.dismiss()) }
                builder.show()
                return result
            }
        }
    }

    private fun openGeckoShop(shop: Shop, animate: Boolean, startUrl: String?) {
        var page = geckoPages[shop.id]
        if (page == null) {
            page = GeckoPage(shop.id, startUrl ?: shop.url)
            geckoPages[shop.id] = page
            trimGecko(shop.id)
        } else if (startUrl != null) {
            page.session.loadUri(startUrl)
        }

        for (w in webViews.values) {
            if (w.parent != null) {
                (w.parent as? ViewGroup)?.removeView(w)
                w.onPause()
            }
        }
        for (g in geckoPages.values) {
            if (g !== page && g.view.parent != null) {
                (g.view.parent as? ViewGroup)?.removeView(g.view)
                g.session.setActive(false)
            }
        }
        if (page.view.parent !== webHolder) {
            (page.view.parent as? ViewGroup)?.removeView(page.view)
            webHolder.addView(page.view, 0, match())
        }
        activeWeb = null
        activeGecko = page
        page.session.setActive(true)

        if (page.painted) {
            main.removeCallbacks(hideCoverRunnable)
            cover.animate().cancel()
            cover.visibility = View.GONE
        } else {
            showCover(shop)
        }
        progressPending = false
        progress.animate().cancel()
        progress.alpha = 0f

        applyShopBars()
        showShopLayer(animate)
        placeBubble()
        bubble.alpha = 1f
        scheduleBubbleIdle()
    }

    private fun trimGecko(keep: String) {
        while (geckoPages.size > 2) {
            val eldest = geckoPages.keys.firstOrNull { it != keep } ?: break
            geckoPages.remove(eldest)?.close()
        }
    }

    private fun onGeckoGone(page: GeckoPage?) {
        if (page == null) {
            closeGeckoPopup()
            return
        }
        geckoPages.remove(page.shopId)
        page.close()
        if (activeGecko === page) {
            activeGecko = null
            val cur = currentShop
            if (cur != null && shopLayer.visibility == View.VISIBLE) openShop(cur, animate = false)
        }
    }

    private fun openGeckoPopup(): GeckoSession {
        closeGeckoPopup()
        val s = newGeckoSession(isWide(currentShop?.id))
        setupGeckoSession(s, null)
        val v = GeckoView(this)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundColor(palette.bg)
        box.isClickable = true
        box.elevation = 10.dp.toFloat()
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(4.dp, 0, 12.dp, 0)
        bar.addView(iconButton(R.drawable.ic_close, "Kapat") { closeGeckoPopup() }, LinearLayout.LayoutParams(50.dp, 50.dp))
        val title = label("Giriş", 16f, palette.sub, "sans-serif-medium")
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        bar.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        box.addView(bar, LinearLayout.LayoutParams(MATCH, 52.dp))
        box.addView(v, LinearLayout.LayoutParams(MATCH, 0, 1f))
        webHolder.addView(box, match())
        v.setSession(s)

        geckoPopupSession = s
        geckoPopupView = v
        geckoPopupBox = box
        geckoPopupTitle = title
        geckoPopupCanGoBack = false
        setBars(palette.bg, palette.bg)

        box.alpha = 0f
        box.translationY = 40.dp.toFloat()
        box.animate().alpha(1f).translationY(0f).setDuration(200).setInterpolator(DecelerateInterpolator()).start()
        return s
    }

    private fun closeGeckoPopup() {
        val s = geckoPopupSession ?: return
        val v = geckoPopupView
        val box = geckoPopupBox
        geckoPopupSession = null
        geckoPopupView = null
        geckoPopupBox = null
        geckoPopupTitle = null
        if (box != null) (box.parent as? ViewGroup)?.removeView(box)
        try { v?.releaseSession() } catch (e: Throwable) { }
        try { s.close() } catch (e: Throwable) { }
        if (::shopLayer.isInitialized && shopLayer.visibility == View.VISIBLE) applyShopBars()
    }

    private fun showAddShopDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(22.dp, 8.dp, 22.dp, 0)
        val nameEt = EditText(this).apply {
            hint = "Mağaza adı (ör. Koton)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            setSingleLine()
        }
        val urlEt = EditText(this).apply {
            hint = "Adresi (ör. koton.com)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
        }
        box.addView(nameEt)
        box.addView(urlEt)
        dialogBuilder()
            .setTitle("Mağaza ekle")
            .setView(box)
            .setPositiveButton("Ekle") { _, _ ->
                val name = nameEt.text.toString().trim()
                var url = urlEt.text.toString().trim().replace(" ", "")
                if (name.isEmpty() || url.isEmpty()) {
                    toast("Mağaza adı ve adresi gerekli")
                    return@setPositiveButton
                }
                if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://$url"
                if (Uri.parse(url).host.isNullOrEmpty()) {
                    toast("Adres geçersiz, ör. koton.com yazın")
                    return@setPositiveButton
                }
                shops.add(Shop("c" + System.currentTimeMillis(), name, url))
                saveShops()
                fillGrid()
                refreshSettingsIfOpen()
                toast("$name eklendi")
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    // ------------------------------------------------------------------ settings

    private fun refreshSettingsIfOpen() {
        if (settingsLayer != null) openSettings(animate = false, keepScroll = true)
    }

    private fun applyPalette(p: Palette) {
        if (p.key == palette.key) return
        palette = p
        prefs.edit().putString("bg", p.key).apply()
        val shopOpen = shopLayer.visibility == View.VISIBLE
        closePopup(null)
        closeGeckoPopup()
        for (w in webViews.values) (w.parent as? ViewGroup)?.removeView(w)
        for (g in geckoPages.values) (g.view.parent as? ViewGroup)?.removeView(g.view)
        buildUi()
        val cur = currentShop
        if (shopOpen && cur != null) openShop(cur, animate = false)
        openSettings(animate = false, keepScroll = false)
    }

    private fun sectionTitle(text: String): TextView =
        label(text, 15f, palette.accent, "sans-serif-medium").apply {
            setPadding(6.dp, 26.dp, 0, 10.dp)
        }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(palette.surface, 20.dp.toFloat())
        setPadding(18.dp, 14.dp, 18.dp, 14.dp)
    }

    private fun actionRow(title: String, sub: String?, color: Int = palette.text, onClick: () -> Unit): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.VERTICAL
        row.setPadding(4.dp, 12.dp, 4.dp, 12.dp)
        row.background = RippleDrawable(csl(withAlpha(palette.text, 0x22)), null, rounded(Color.WHITE, 12.dp.toFloat()))
        row.isClickable = true
        row.addView(label(title, 16f, color, "sans-serif-medium"))
        if (sub != null) row.addView(label(sub, 13f, palette.sub).apply { setPadding(0, 3.dp, 0, 0) })
        row.setOnClickListener { onClick() }
        return row
    }

    private fun switchRow(title: String, sub: String, key: String, def: Boolean, onChange: (Boolean) -> Unit): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(4.dp, 12.dp, 4.dp, 12.dp)
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.addView(label(title, 16f, palette.text, "sans-serif-medium"))
        texts.addView(label(sub, 13f, palette.sub).apply { setPadding(0, 3.dp, 12.dp, 0) })
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = Switch(this)
        sw.isChecked = prefs.getBoolean(key, def)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(palette.accent, palette.sub))
        sw.trackTintList = ColorStateList(states, intArrayOf(withAlpha(palette.accent, 0x77), withAlpha(palette.sub, 0x55)))
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean(key, on).apply()
            onChange(on)
        }
        row.addView(sw)
        row.isClickable = true
        row.setOnClickListener { sw.toggle() }
        return row
    }

    private fun openSettings(animate: Boolean, keepScroll: Boolean = false) {
        val oldScroll = if (keepScroll) (settingsScroll?.scrollY ?: 0) else 0
        settingsLayer?.let { root.removeView(it) }

        val layer = LinearLayout(this)
        layer.orientation = LinearLayout.VERTICAL
        layer.setBackgroundColor(palette.bg)
        layer.isClickable = true

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(4.dp, 0, 4.dp, 0)
        bar.addView(iconButton(R.drawable.ic_back, "Geri") { closeSettings() }, LinearLayout.LayoutParams(50.dp, 50.dp))
        bar.addView(label("Ayarlar", 21f, palette.text, "sans-serif-medium").apply { setPadding(8.dp, 0, 0, 0) },
            LinearLayout.LayoutParams(0, WRAP, 1f))
        layer.addView(bar, LinearLayout.LayoutParams(MATCH, 58.dp))

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val screenW = resources.displayMetrics.widthPixels
        val side = Math.max(16.dp, (screenW - 720.dp) / 2)
        col.setPadding(side, 0, side, 40.dp)

        // Background colour
        col.addView(sectionTitle("Arka plan rengi"))
        val colors = card()
        val swatches = LinearLayout(this)
        swatches.orientation = LinearLayout.HORIZONTAL
        for (p in PALETTES) {
            val selected = p.key == palette.key
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER_HORIZONTAL
            item.setPadding(0, 8.dp, 0, 8.dp)
            item.isClickable = true
            item.background = RippleDrawable(csl(withAlpha(palette.text, 0x22)), null, rounded(Color.WHITE, 14.dp.toFloat()))
            val circleBox = FrameLayout(this)
            val circle = View(this)
            circle.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(p.bg)
                if (selected) setStroke(3.dp, palette.accent) else setStroke(1.dp, c(0x66888888))
            }
            circleBox.addView(circle, FrameLayout.LayoutParams(MATCH, MATCH))
            if (selected) {
                val tick = label("✓", 22f, if (p.light) Color.BLACK else Color.WHITE, "sans-serif-medium")
                tick.gravity = Gravity.CENTER
                circleBox.addView(tick, FrameLayout.LayoutParams(MATCH, MATCH))
            }
            item.addView(circleBox, LinearLayout.LayoutParams(52.dp, 52.dp))
            item.addView(label(p.label, 13f, if (selected) palette.text else palette.sub, "sans-serif-medium").apply {
                gravity = Gravity.CENTER
                setPadding(0, 8.dp, 0, 0)
            })
            item.setOnClickListener { applyPalette(p) }
            swatches.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        colors.addView(swatches)
        col.addView(colors)

        // Speed
        col.addView(sectionTitle("Hız"))
        val speed = card()
        speed.addView(switchRow("Reklam ve takip engelleyici",
            "Mağaza sayfalarındaki reklam ve izleme kodlarını yüklemez, sayfalar daha hızlı açılır", "block", true) { on ->
            blockTrackers = on
            activeWeb?.reload()
        })
        speed.addView(switchRow("İlk 3 mağazayı önceden hazırla",
            "Uygulama açılınca ana sayfadaki ilk 3 mağaza arka planda yüklenir, dokununca bekletmeden açılır", "preload", true) { on ->
            if (on) preloadTopShops()
        })
        col.addView(speed)

        col.addView(sectionTitle("Google ile giriş"))
        val google = card()
        google.addView(label("Bir mağazada \"Google ile giriş\"e dokunduğunuzda o mağaza kendiliğinden Firefox motoruna geçer, " +
            "çünkü Google girişe sadece tam tarayıcı motorlarında izin veriyor. Bu mağazalar biraz daha geç açılabilir.", 14f, palette.sub).apply {
            setPadding(4.dp, 6.dp, 4.dp, 6.dp)
            setLineSpacing(0f, 1.15f)
        })
        val geckoNames = shops.filter { isGecko(it.id) }.joinToString(", ") { it.name }
        google.addView(label(if (geckoNames.isEmpty()) "Şu an Firefox motoruyla açılan mağaza yok." else "Firefox motoruyla açılanlar: $geckoNames",
            14f, palette.text, "sans-serif-medium").apply { setPadding(4.dp, 8.dp, 4.dp, 6.dp) })
        google.addView(label("Bir mağazayı elle değiştirmek için ana sayfada o mağazaya basılı tutun.", 13f, palette.sub).apply {
            setPadding(4.dp, 4.dp, 4.dp, 6.dp)
        })
        col.addView(google)

        // Shops
        col.addView(sectionTitle("Ana sayfadaki mağazalar"))
        val list = card()
        for ((index, shop) in shops.withIndex()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, 4.dp, 0, 4.dp)
            val texts = LinearLayout(this)
            texts.orientation = LinearLayout.VERTICAL
            texts.addView(label(shop.name, 16f, palette.text, "sans-serif-medium"))
            texts.addView(label(hostOf(shop.url).removePrefix("www."), 12f, palette.sub))
            row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))
            val upBtn = iconButton(R.drawable.ic_up, "Yukarı", if (index > 0) palette.text else palette.divider) {
                if (index > 0) {
                    shops.removeAt(index)
                    shops.add(index - 1, shop)
                    saveShops(); fillGrid(); refreshSettingsIfOpen()
                }
            }
            val downBtn = iconButton(R.drawable.ic_down, "Aşağı", if (index < shops.size - 1) palette.text else palette.divider) {
                if (index < shops.size - 1) {
                    shops.removeAt(index)
                    shops.add(index + 1, shop)
                    saveShops(); fillGrid(); refreshSettingsIfOpen()
                }
            }
            val delBtn = iconButton(R.drawable.ic_close, "Kaldır", palette.sub) {
                removeShop(shop)
                saveShops(); fillGrid(); refreshSettingsIfOpen()
            }
            row.addView(upBtn, LinearLayout.LayoutParams(44.dp, 44.dp))
            row.addView(downBtn, LinearLayout.LayoutParams(44.dp, 44.dp))
            row.addView(delBtn, LinearLayout.LayoutParams(44.dp, 44.dp))
            list.addView(row)
        }
        if (shops.isEmpty()) list.addView(label("Ana sayfada mağaza yok. Aşağıdan ekleyin.", 14f, palette.sub))
        list.addView(label("İpucu: Bir mağaza tablette dar ya da eksik görünürse ana sayfada o mağazaya basılı tutup \"Geniş görünümde aç\"ı seçin.", 13f, palette.sub).apply {
            setPadding(4.dp, 10.dp, 4.dp, 4.dp)
        })
        list.addView(actionRow("Mağaza ekle", "Adını ve web adresini yazmanız yeterli", palette.accent) { showAddShopDialog() })
        list.addView(actionRow("Hazır mağaza listesini geri yükle", "Eklediğiniz mağazalar korunur") {
            val existing = shops.map { it.id }.toSet()
            for (d in defaultShops()) if (d.id !in existing) shops.add(d)
            saveShops(); fillGrid(); refreshSettingsIfOpen()
            toast("Hazır mağazalar geri geldi")
        })
        col.addView(list)

        // Accounts & data
        col.addView(sectionTitle("Hesaplar ve veriler"))
        val data = card()
        data.addView(actionRow("Önbelleği temizle", "Sayfalar düzgün yüklenmezse işe yarar, hesaplarınız açık kalır") {
            val w = activeWeb ?: spare ?: webViews.values.firstOrNull()
            if (w != null) w.clearCache(true) else WebView(this).apply { clearCache(true); destroy() }
            toast("Önbellek temizlendi")
        })
        data.addView(actionRow("Tüm mağaza hesaplarından çıkış yap", "Giriş bilgileri, sepet çerezleri ve site verileri silinir", c(0xFFE5484D)) {
            dialogBuilder()
                .setTitle("Tüm hesaplardan çıkılsın mı?")
                .setMessage("Bütün mağazalarda yeniden giriş yapmanız gerekecek.")
                .setPositiveButton("Çıkış yap") { _, _ -> signOutEverywhere() }
                .setNegativeButton("Vazgeç", null)
                .show()
        })
        col.addView(data)

        @Suppress("DEPRECATION")
        val version = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
        col.addView(label("Online AVM $version", 13f, palette.sub).apply {
            gravity = Gravity.CENTER
            setPadding(0, 28.dp, 0, 0)
        }, LinearLayout.LayoutParams(MATCH, WRAP))

        scroll.addView(col)
        layer.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        root.addView(layer, match())
        settingsLayer = layer
        settingsScroll = scroll
        if (oldScroll > 0) scroll.post { scroll.scrollTo(0, oldScroll) }

        if (animate) {
            layer.alpha = 0f
            layer.translationX = 30.dp.toFloat()
            layer.animate().alpha(1f).translationX(0f).setDuration(190).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun closeSettings() {
        val l = settingsLayer ?: return
        settingsLayer = null
        settingsScroll = null
        l.animate().alpha(0f).translationX(30.dp.toFloat()).setDuration(160).withEndAction { root.removeView(l) }.start()
    }

    private fun signOutEverywhere() {
        closePopup(null)
        closeGeckoPopup()
        for (w in webViews.values) destroyWeb(w)
        webViews.clear()
        for (g in geckoPages.values) g.close()
        geckoPages.clear()
        activeGecko = null
        if (geckoIds().isNotEmpty()) {
            try { geckoRuntime().storageController.clearData(StorageController.ClearFlags.ALL) } catch (e: Throwable) { }
        }
        activeWeb = null
        currentShop = null
        fillGrid()
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        toast("Tüm hesaplardan çıkış yapıldı")
    }
}
